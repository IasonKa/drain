# drainopt — parametric drain CAD + simulation-domain automation

Parametric rebuild of `drainage-3D` (Inventor 2025) and an automated pipeline
that turns a set of design parameters into CAD, metrics and simulation meshes,
one design per job, ready for a CPU cluster.

## Status

| Step | State |
|---|---|
| Parametric CAD of body, holes, taper, tube (`drainopt/cad.py`) | working, validated |
| Geometric/analytical metrics (`drainopt/metrics.py`) | working |
| Tissue-domain tet mesh + perforation facet sets (`mesh_tissue`) | working |
| Design of experiments + per-design runner + SLURM array | working (CAD, tissue) |
| CFD fluid-domain mesh (gmsh, `mesh_fluid`) | **fails** on sliver/thin-gap geometry; being replaced by snappyHexMesh |
| OpenFOAM case, FEBio input, optimiser loop | next |

## Validation against the original (`scripts/validate_baseline.py`)

| Quantity | Reference | Parametric |
|---|---|---|
| Perforations | 324 | 324 (max position error 0.04 mm) |
| Surface area | 32 370 mm² | −0.4 % |
| Volume | 9 728 mm³ | −2.7 % (CAD) |
| Section material area | 58.1 mm² | 57.7 mm² |
| Surface deviation, body | — | mean 0.17 mm, 95 % < 0.34 mm |

Known simplifications: rib "feet" omitted; the taper wall is thinner than the
reference (~0.5 vs ~0.8 mm); the tube path is a smoothed fit of the measured centreline.

## What the geometry is (CAD frame: +z = drain axis, tip at z = 0, x = major axis)

- **Outer sheath**: oval 17.9 × 9.7 mm, wall 0.62 mm, 16 inward ribs, 4 gussets, 2 wedges.
- **Inner core**: slotted tube (OD 5.6 / ID 4.22 mm, 6 slots, 6-spoke star), continuous with the extension tube.
- **Perforations**: 54 rows × 6 holes, Ø1.0 mm, through-all along y, 2.25 mm row pitch, 3.3 mm hole pitch, 0.76 mm stagger.
- **Ends**: open tip; 11.5 mm taper into the tube. **Tube**: ~279 mm, tightest bend ~5 mm.

**Flow path:** holes / open tip → sheath channels → (dead-ends at the taper) → 6 core
slots → core → tube. The slots and the tip are likely bottlenecks and are design variables.

## Quick start

```bash
pip install cadquery gmsh trimesh shapely scipy numpy networkx rtree matplotlib
# Linux also needs: libglu1-mesa libxcursor1 libxinerama1 libxft2
python3 scripts/build_baseline.py --out out/baseline                  # ~90 s
python3 scripts/validate_baseline.py --ref drainage-3D.stl --cad out/baseline/drain.stl
python3 scripts/generate_variants.py --n 40 --out runs/doe1 --segment-rows 8   # plan only
python3 scripts/run_variant.py --manifest runs/doe1/manifest.csv --index 0 --tissue
```

On the cluster: build `hpc/drainopt.def` into `drainopt.sif`, then
`sbatch --array=0-40%20 hpc/slurm_variants.sh runs/doe1/manifest.csv`.

## Design variables (`params.DESIGN_SPACE`)

hole Ø, holes per row, hole pitch, row pitch, stagger, sheath wall, sheath minor
axis, rib count/height, core slot count/width, open/closed tip. `from_unit()` maps
a sample in [0,1]^d to a buildable design (it rescales wedges/gussets and the hole
pitch when the oval gets thinner), and `DrainParams.check()` rejects the rest.

`--segment-rows N` builds short "section models" (same cross-section and holes, N rows)
for fast hole-level screening; `0` builds the full 120 mm drain.

## Outputs per design (`runs/<doe>/vNNNN/`)

`params.json`, `drain.step/.stl`, `fluid.step` + `fluid_info.json`,
`tissue.step`, `tissue.msh` (MSH 2.2; groups `tissue`, `far`, `interface`),
`tissue_hole_facets.json` (interface triangles over each perforation = suction patches),
`result.json` (status, metrics, mesh statistics).

## Implementation notes

- Meshing runs in a **separate process**: gmsh bundles its own OpenCascade, which
  segfaults if loaded next to CadQuery's in one interpreter.
- Each mesh attempt runs in a fresh process (HXT, then Delaunay), because a mesher
  crash cannot be caught inside Python.
- Geometry is healed at 20 µm before meshing.
- The full tube is a separate solid touching the taper (fusing the B-spline sweep with
  the 324-hole body is very slow and unnecessary for meshing).

## Next steps

1. Fluid meshing via OpenFOAM `snappyHexMesh` from `drain.stl` (robust to grazing holes and thin gaps).
2. OpenFOAM case template: steady laminar, pressure at cavity faces, suction at the outlet;
   tube resistance added analytically (`metrics.tube_R_hyd`).
3. FEBio biphasic tissue model on `tissue.msh`: contact on `interface`, suction (fluid
   pressure) on the hole facets.
4. Surrogate model + multi-objective optimisation (Optuna / BoTorch) over the DOE results.

Clinical inputs still needed: fluid type (viscosity), suction level, tissue type and properties.
