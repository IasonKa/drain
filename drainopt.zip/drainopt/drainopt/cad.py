"""
Parametric CAD for the perforated drain (CadQuery / OpenCascade).

    build_section(p)          -> cq.Sketch of the body cross-section
    build_body(p)             -> perforated body (sheath + slotted core), with holes
    build_taper(p)            -> oval -> tube transition
    build_tube(p, mode)       -> extension tube ('full' measured path, 'stub', 'none')
    build_drain(p, tube=...)  -> complete solid
    build_fluid_domain(p)     -> CFD domain: box of fluid around the drain + outlet stub
    build_tissue_domain(p)    -> FE domain: tissue block with the drain envelope removed
"""
from __future__ import annotations
import math, os
import numpy as np
import cadquery as cq
from cadquery import Vector

from .params import DrainParams

DATA = os.path.join(os.path.dirname(__file__), "data")


# --------------------------------------------------------------------------
# 2D helpers
# --------------------------------------------------------------------------
def _ellipse_arclength_table(a, b, n=4000):
    th = np.linspace(0, 2 * np.pi, n + 1)
    x, y = a * np.cos(th), b * np.sin(th)
    s = np.r_[0, np.cumsum(np.hypot(np.diff(x), np.diff(y)))]
    return th, s


def _ellipse_point(a, b, th):
    p = np.array([a * math.cos(th), b * math.sin(th)])
    n_out = np.array([p[0] / a**2, p[1] / b**2]); n_out /= np.linalg.norm(n_out)
    tang = np.array([-n_out[1], n_out[0]])
    return p, n_out, tang


def _rect_on_wall(p0, n_out, tang, height, width, into_wall):
    """Rectangle standing on the inner wall at p0, pointing inward."""
    n_in = -n_out
    b0 = p0 - n_in * into_wall
    b1 = p0 + n_in * height
    hw = tang * width / 2
    return [tuple(b0 - hw), tuple(b0 + hw), tuple(b1 + hw), tuple(b1 - hw)]


def _poly_radial(angle, r0, r1, w0, w1):
    """Tapered radial bar from radius r0 (width w0) to r1 (width w1)."""
    u = np.array([math.cos(angle), math.sin(angle)]); v = np.array([-u[1], u[0]])
    pts = [u * r0 - v * w0 / 2, u * r1 - v * w1 / 2, u * r1 + v * w1 / 2, u * r0 + v * w0 / 2]
    return [tuple(q) for q in pts]


def section_polygons(p: DrainParams):
    """Return the features of the cross-section as plain data (also used for metrics)."""
    a, b, t = p.sheath_a, p.sheath_b, p.sheath_t
    ai, bi = a - t, b - t
    into = 0.7 * t                       # how far features overlap into the wall
    feats = {"ribs": [], "gussets": [], "wedges": [], "spokes": [], "slots": []}

    # ribs: explicit quadrant angles (mirrored 4-fold) ...
    if p.rib_angles:
        for ang in p.rib_angles:
            for th in np.radians([ang, 180 - ang, 180 + ang, 360 - ang]):
                p0, n_out, tg = _ellipse_point(ai, bi, float(th))
                feats["ribs"].append(_rect_on_wall(p0, n_out, tg, p.rib_h, p.rib_w, into))
    # ... or n_ribs evenly spaced by arc length on the inner ellipse
    elif p.n_ribs > 0:
        th_tab, s_tab = _ellipse_arclength_table(ai, bi)
        S = s_tab[-1]
        for k in range(p.n_ribs):
            s = (k + p.rib_phase) * S / p.n_ribs
            th = float(np.interp(s % S, s_tab, th_tab))
            p0, n_out, tg = _ellipse_point(ai, bi, th)
            feats["ribs"].append(_rect_on_wall(p0, n_out, tg, p.rib_h, p.rib_w, into))

    # triangular gussets (vertical inner edge at |x| = gusset_x), one per quadrant
    if p.gusset_leg > 0 and p.gusset_x + p.gusset_leg < ai:
        yw = lambda x: bi * math.sqrt(max(0.0, 1 - (x / ai) ** 2))
        g0, g1 = p.gusset_x, p.gusset_x + p.gusset_leg
        base = [(g0, yw(g0) + into), (g0, yw(g0) - p.gusset_depth),
                (g1, yw(g1)), (g1, yw(g1) + into)]
        for sx in (1, -1):
            for sy in (1, -1):
                feats["gussets"].append([(sx * x, sy * y) for x, y in base])

    # trapezoid wedges at top / bottom centre
    if p.wedge_h > 0:
        for sgn in (+1, -1):
            yb = sgn * (bi + into); yt = sgn * (bi - p.wedge_h)
            feats["wedges"].append([(-0.70, yb), (0.70, yb), (0.25, yt), (-0.25, yt)])

    # core: spokes (internal star) and slots (through the core wall)
    for k in range(p.n_spokes):
        ang = 2 * math.pi * (k + 0.5) / p.n_spokes
        feats["spokes"].append(_poly_radial(ang, 0.0, p.core_ri + 0.3, p.spoke_w_root, p.spoke_w_tip))
    for k in range(p.n_slots):
        ang = 2 * math.pi * k / p.n_slots
        feats["slots"].append(_poly_radial(ang, p.core_ri - 0.05, p.core_ro + 0.05, p.slot_w, p.slot_w))
    return feats


def _face_poly(pts):
    pts = list(pts)
    area2 = sum(x0 * y1 - x1 * y0 for (x0, y0), (x1, y1) in zip(pts, pts[1:] + pts[:1]))
    if area2 < 0:                       # force counter-clockwise (normal +z)
        pts = pts[::-1]
    return cq.Face.makeFromWires(cq.Wire.makePolygon([Vector(x, y, 0) for x, y in pts], close=True))


def _face_ellipse(a, b):
    return cq.Face.makeFromWires(cq.Wire.makeEllipse(a, b, Vector(0, 0, 0), Vector(0, 0, 1), Vector(1, 0, 0)))


def _face_circle(r):
    return cq.Face.makeFromWires(cq.Wire.makeCircle(r, Vector(0, 0, 0), Vector(0, 0, 1)))


def build_section(p: DrainParams, which="all"):
    """Cross-section as a list of cq.Face. which: 'all' | 'sheath' | 'core'."""
    a, b, t = p.sheath_a, p.sheath_b, p.sheath_t
    f = section_polygons(p)
    shapes = []
    if which in ("all", "sheath"):
        sh = _face_ellipse(a, b).cut(_face_ellipse(a - t, b - t))
        add = [_face_poly(q) for k in ("ribs", "gussets", "wedges") for q in f[k]]
        if add:
            sh = sh.fuse(*add)
        shapes.append(sh.clean())
    if which in ("all", "core"):
        co = _face_circle(p.core_ro).cut(_face_circle(p.core_ri))
        if f["spokes"]:
            co = co.fuse(*[_face_poly(q) for q in f["spokes"]])
        if f["slots"]:
            co = co.cut(*[_face_poly(q) for q in f["slots"]])
        shapes.append(co.clean())
    return [fc for s_ in shapes for fc in s_.Faces()]


# --------------------------------------------------------------------------
# 3D parts
# --------------------------------------------------------------------------
def hole_centres(p: DrainParams):
    """(x, z) of every perforation axis (holes run along y, through-all)."""
    out = []
    for i in range(p.n_rows):
        z = p.first_row_z + i * p.row_pitch
        if z < -p.hole_d / 2 or z > p.body_len + p.hole_d / 2:
            continue
        x0 = p.row_x_offset - (i % 2) * p.row_stagger
        for j in range(p.holes_per_row):
            x = x0 + (j - (p.holes_per_row - 1) / 2) * p.hole_pitch_x
            if abs(x) - p.hole_d / 2 < p.sheath_a:     # keep holes that nick the oval ends
                out.append((x, z))
    return out


def build_holes(p: DrainParams):
    r = p.hole_d / 2; L = 2 * p.sheath_b + 2.0
    cyl = [cq.Solid.makeCylinder(r, L, Vector(x, -p.sheath_b - 1.0, z), Vector(0, 1, 0))
           for x, z in hole_centres(p)]
    return cq.Compound.makeCompound(cyl) if cyl else None


def build_body(p: DrainParams) -> cq.Workplane:
    solids = [cq.Solid.extrudeLinear(fc, Vector(0, 0, p.body_len)) for fc in build_section(p)]
    body = cq.Workplane().add(solids[0])
    for s_ in solids[1:]:
        body = body.union(cq.Workplane().add(s_))
    holes = build_holes(p)
    if holes is not None:
        body = body.cut(cq.Workplane().add(holes))
    if p.tip_closed:
        cap = (cq.Workplane("XY").workplane(offset=-p.tip_cap_t)
               .ellipse(p.sheath_a, p.sheath_b).extrude(p.tip_cap_t))
        body = body.union(cap)
    return body


def build_taper(p: DrainParams) -> cq.Workplane:
    z0, z1 = p.body_len, p.body_len + p.taper_len
    Z = Vector(0, 0, 1); X = Vector(1, 0, 0)
    outer = cq.Solid.makeLoft([
        cq.Wire.makeEllipse(p.sheath_a, p.sheath_b, Vector(0, 0, z0), Z, X),
        cq.Wire.makeCircle(p.taper_end_r, Vector(0, 0, z1), Z)], True)
    inner = cq.Solid.makeLoft([
        cq.Wire.makeEllipse(p.sheath_a - p.sheath_t, p.sheath_b - p.sheath_t, Vector(0, 0, z0), Z, X),
        cq.Wire.makeCircle(p.tube_ro, Vector(0, 0, z1), Z)], True)
    core = (cq.Workplane("XY").workplane(offset=z0)
            .circle(p.core_ro).circle(p.core_ri).extrude(p.taper_len))
    return cq.Workplane().add(outer).cut(cq.Workplane().add(inner)).union(core)


def tube_path_points(p: DrainParams, spacing=2.0):
    """Smoothed centreline of the extension tube, starting on the drain axis at the taper end."""
    z0 = p.body_len + p.taper_len
    if p.tube_path == "straight":
        return np.array([[0, 0, z0], [0, 0, z0 + p.tube_len_straight]])
    src = os.path.join(DATA, "tube_path_baseline.csv") if p.tube_path == "baseline" else p.tube_path
    P = np.loadtxt(src, delimiter=",", comments="#")
    # blend the measured start onto the drain axis over the first 20 mm
    s = np.r_[0, np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))]
    w = np.clip(1 - s / 20.0, 0, 1)[:, None]
    P = P.copy(); P[:, :2] -= w * P[0, :2]
    if P[0, 2] < z0 + 0.5:              # body/taper got longer: shift path along +z
        P[:, 2] += z0 + 0.5 - P[0, 2]
    P = np.vstack([[0.0, 0.0, z0], P])
    # smoothing spline (removes measurement noise / cusps), resampled every `spacing` mm
    from scipy.interpolate import splprep, splev
    s_ = np.r_[0, np.cumsum(np.linalg.norm(np.diff(P, axis=0), axis=1))]
    keep = np.r_[True, np.diff(s_) > 1e-6]
    P, s_ = P[keep], s_[keep]
    wt = np.ones(len(P)); wt[:2] = 50.0                 # pin the start on the drain axis
    tck, _ = splprep(P.T, u=s_ / s_[-1], w=wt, s=len(P) * 0.15, k=3)
    u = np.linspace(0, 1, max(20, int(s_[-1] / spacing)))
    Q = np.array(splev(u, tck)).T
    Q[0] = [0.0, 0.0, z0]
    return Q


def min_bend_radius(P):
    """Discrete estimate of the smallest bend radius along a polyline."""
    d = np.diff(P, axis=0); L = np.linalg.norm(d, axis=1); T = d / L[:, None]
    dth = np.arccos(np.clip((T[1:] * T[:-1]).sum(1), -1, 1))
    ds = 0.5 * (L[1:] + L[:-1])
    with np.errstate(divide="ignore"):
        return float(np.min(ds / np.maximum(dth, 1e-12)))


def build_tube(p: DrainParams, mode="full", stub_len=15.0):
    z0 = p.body_len + p.taper_len
    if mode == "none":
        return None
    if mode == "stub":
        return (cq.Workplane("XY").workplane(offset=z0)
                .circle(p.tube_ro).circle(p.tube_ri).extrude(stub_len))
    P = tube_path_points(p)
    if len(P) == 2:
        return (cq.Workplane("XY").workplane(offset=z0)
                .circle(p.tube_ro).circle(p.tube_ri).extrude(float(P[1, 2] - z0)))
    path = cq.Wire.assembleEdges([cq.Edge.makeSpline([Vector(*map(float, q)) for q in P])])
    Z = Vector(0, 0, 1); c0 = Vector(0, 0, z0)
    tube = cq.Solid.sweep(cq.Wire.makeCircle(p.tube_ro, c0, Z),
                          [cq.Wire.makeCircle(p.tube_ri, c0, Z)], path, True, False)
    return cq.Workplane().add(tube)


def build_drain(p: DrainParams, tube="full", stub_len=15.0, fuse_tube=None) -> cq.Workplane:
    """
    Complete drain. The body+taper is one fused solid. A full swept tube is kept
    as a second solid touching the taper end (fusing the B-spline sweep with the
    324-hole body is very slow in OCC and gives no benefit for meshing: gmsh
    fragments/merges the shared face). Straight stubs are fused (cheap).
    """
    d = build_body(p).union(build_taper(p))
    t = build_tube(p, tube, stub_len)
    if t is None:
        return d
    if fuse_tube is None:
        fuse_tube = tube != "full"
    if fuse_tube:
        return d.union(t)
    return cq.Workplane().add(cq.Compound.makeCompound(d.solids().vals() + t.solids().vals()))


# --------------------------------------------------------------------------
# Simulation domains
# --------------------------------------------------------------------------
def build_fluid_domain(p: DrainParams, margin=4.0, stub_len=15.0, inbox_tube=4.0):
    """
    Fluid region for CFD screening:
      a box of fluid (the wound cavity / collection) around the drain body,
      the drain lumens (connected through holes, slots and the open tip),
      and a straight outlet stub of the tube sticking out of the box.
    Returns (fluid_solid, info) where info holds the planes used to tag boundaries.
    """
    z_top = p.body_len + p.taper_len + inbox_tube
    z_bot = -margin - (p.tip_cap_t if p.tip_closed else 0.0)
    z_out = p.body_len + p.taper_len + stub_len
    hx, hy = p.sheath_a + margin, p.sheath_b + margin
    box = cq.Workplane("XY").box(2 * hx, 2 * hy, z_top - z_bot, centered=(True, True, False)) \
        .translate((0, 0, z_bot))
    drain = build_drain(p, tube="stub", stub_len=stub_len)
    fluid = box.cut(drain)
    lumen = (cq.Workplane("XY").workplane(offset=z_top - 1.0)
             .circle(p.tube_ri).extrude(z_out - z_top + 1.0))
    fluid = fluid.union(lumen)
    info = dict(x=(-hx, hx), y=(-hy, hy), z=(z_bot, z_top), z_outlet=z_out)
    return fluid, info


def build_tissue_domain(p: DrainParams, margin=10.0, inbox_tube=4.0):
    """
    Tissue block for the poroelastic (biphasic) model.
    The drain *envelope* (outer surface of sheath + taper + tube) is removed.
    Perforation openings are NOT imprinted in the CAD; mesh.py selects the
    interface facets that lie over each hole (geometric selection), which is
    robust on the curved oval surface and independent of the mesh.
    """
    z_top = p.body_len + p.taper_len + inbox_tube
    z_bot = -margin
    hx, hy = p.sheath_a + margin, p.sheath_b + margin
    box = cq.Workplane("XY").box(2 * hx, 2 * hy, z_top - z_bot, centered=(True, True, False)) \
        .translate((0, 0, z_bot))
    # envelope = solid oval body + taper + tube, then holes re-opened as pockets
    env = cq.Workplane("XY").ellipse(p.sheath_a, p.sheath_b).extrude(p.body_len)
    if p.tip_closed:
        env = env.union(cq.Workplane("XY").workplane(offset=-p.tip_cap_t)
                        .ellipse(p.sheath_a, p.sheath_b).extrude(p.tip_cap_t))
    z0, z1 = p.body_len, p.body_len + p.taper_len
    Z = Vector(0, 0, 1)
    env = env.union(cq.Workplane().add(cq.Solid.makeLoft([
        cq.Wire.makeEllipse(p.sheath_a, p.sheath_b, Vector(0, 0, z0), Z, Vector(1, 0, 0)),
        cq.Wire.makeCircle(p.taper_end_r, Vector(0, 0, z1), Z)], True)))
    env = env.union(cq.Workplane("XY").workplane(offset=z1).circle(p.tube_ro)
                    .extrude(z_top - z1 + 1.0))
    tissue = box.cut(env)
    info = dict(x=(-hx, hx), y=(-hy, hy), z=(z_bot, z_top), holes=hole_centres(p))
    return tissue, info


# --------------------------------------------------------------------------
def export(wp: cq.Workplane, stem: str, stl=True, step=True, tol=0.05):
    if step:
        cq.exporters.export(wp, stem + ".step")
    if stl:
        cq.exporters.export(wp, stem + ".stl", tolerance=tol, angularTolerance=0.3)
