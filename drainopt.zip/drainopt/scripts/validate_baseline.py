"""
Compare the parametric baseline against the original Inventor export.

  python scripts/validate_baseline.py --ref drainage-3D.stl --cad out/baseline/drain.stl
Outputs: <out>/validation.png and validation.json
"""
import sys, os, json, argparse
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import numpy as np, trimesh, matplotlib
matplotlib.use("Agg"); import matplotlib.pyplot as plt
from scipy.spatial import cKDTree
from drainopt.params import BASELINE as p
from drainopt import cad

ap = argparse.ArgumentParser()
ap.add_argument("--ref", required=True); ap.add_argument("--cad", required=True)
ap.add_argument("--out", default=None)
a = ap.parse_args(); out = a.out or os.path.dirname(a.cad)
D = os.path.join(os.path.dirname(cad.__file__), "data")
M = np.array(json.load(open(os.path.join(D, "reference_frame.json")))["matrix"])
ref = trimesh.load(a.ref); ref.apply_transform(M)
our = trimesh.load(a.cad)
rep = {"ref_volume": ref.volume, "cad_volume": our.volume,
       "volume_err_pct": 100 * (our.volume / ref.volume - 1),
       "ref_area": ref.area, "cad_area": our.area,
       "area_err_pct": 100 * (our.area / ref.area - 1)}

def surf_dist(A, B, n=60000, nB=400000, zlim=None):
    pa, _ = trimesh.sample.sample_surface(A, n, seed=0)
    pb, _ = trimesh.sample.sample_surface(B, nB, seed=1)
    if zlim:
        pa = pa[(pa[:, 2] > zlim[0]) & (pa[:, 2] < zlim[1])]
        pb = pb[(pb[:, 2] > zlim[0] - 2) & (pb[:, 2] < zlim[1] + 2)]
    d, _ = cKDTree(pb).query(pa)
    return d
for name, zl in [("body", (2, p.body_len - 2)), ("whole", None)]:
    d1 = surf_dist(our, ref, zlim=zl); d2 = surf_dist(ref, our, zlim=zl)
    d = np.r_[d1, d2]
    rep[f"dist_{name}_mean"] = float(d.mean()); rep[f"dist_{name}_p95"] = float(np.percentile(d, 95))
    rep[f"dist_{name}_max"] = float(d.max())
# holes
H = np.loadtxt(os.path.join(D, "reference_holes.csv"), delimiter=",")
C = np.array(cad.hole_centres(p))
dh, _ = cKDTree(C).query(H)
rep.update(ref_holes=len(H), cad_holes=len(C), hole_pos_err_max=float(dh.max()))

fig, axs = plt.subplots(1, 3, figsize=(19, 5.5))
zs = [p.first_row_z + 20.5 * p.row_pitch, p.first_row_z + 26 * p.row_pitch, p.body_len + 5.0]
for axp, z in zip(axs, zs):
    for mesh, col, lab in [(ref, "r", "reference"), (our, "b", "parametric")]:
        s = mesh.section(plane_origin=[0, 0, z], plane_normal=[0, 0, 1])
        if s is None:
            continue
        for e in s.discrete:
            if np.abs(e[:, :2]).max() < 12:
                axp.plot(e[:, 0], e[:, 1], col + "-", lw=0.9)
    axp.set_aspect("equal"); axp.grid(alpha=.3); axp.set_title(f"section z = {z:.1f} mm")
axs[0].plot([], [], "r-", label="reference"); axs[0].plot([], [], "b-", label="parametric"); axs[0].legend()
plt.tight_layout(); plt.savefig(os.path.join(out, "validation.png"), dpi=90)
json.dump(rep, open(os.path.join(out, "validation.json"), "w"), indent=2)
for k, v in rep.items():
    print(f"  {k:22s} {v:.4g}" if isinstance(v, float) else f"  {k:22s} {v}")
