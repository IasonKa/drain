@echo off
cd /d "%~dp0"
py -3.12 prepare_dataset_rois.py
pause
