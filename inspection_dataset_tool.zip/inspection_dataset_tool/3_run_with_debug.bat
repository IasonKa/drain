@echo off
rem Same as 3_run.bat, plus overlay pictures in _debug to check the ROI boxes.
cd /d "%~dp0"
py -3.12 prepare_dataset_rois.py --debug
pause
