"""
BOTTOM-FEATURE-DETECTION
========================

Finds the orientation, tilt and all features of BOTTOM images and writes annotated
copies: 16 pins, white triangle, the two white boxes and the gray box.

Canonical orientation (as in the reference image): white boxes on the left and right
edges near the top, gray box on the right edge below the right white box, triangle in
the bottom-right corner.

How it works
    0. Fit a square to the die                 -> coarse centre and scale
    1. Find the 4x4 pin lattice (robust, works with missing / damaged pins)
                                               -> exact centre, pitch (scale) and tilt
       The lattice looks the same at 0/90/180/270 deg, so it does not give the rotation.
    2. For each of the 4 possible rotations, warp the image into the reference frame
       (rotation + tilt + scale undone) and score the evidence where the triangle,
       the two white boxes and the gray box must be for that rotation:
         triangle  : template match + "is it white" contrast test
         white box : match on the white OUTLINE only (the symbols inside change)
                     + "is it white" contrast test
         gray box  : template match
       This is your corner / side ROI idea, done for all four rotations at once:
       a rotation is only chosen when triangle AND boxes agree, so one destroyed
       feature does not flip the result.
    3. The frame is corrected with every pin and feature that matched well (RANSAC),
       then every feature and pin is searched again in a small ROI.
       Features never move on the unit, so their outlines come from this geometry;
       the match only decides "matched" (solid) or "weak" (dashed: damaged, painted,
       covered). Pins use their matched position, or the lattice node when weak.

Outputs (OUTPUT_DIR): annotated copies, bottom_results.csv, bottom_results.json,
optionally canonical/ (deskewed, correctly rotated copies).
"""

import csv
import json
import math
import time
from pathlib import Path

import cv2
import numpy as np

# ============================================================
# PATHS  (edit these)
# ============================================================

BASE_DIR = r"C:\Users\laka\software\Automated_Inspection\detect_claude\BOTTOM"

INPUT_DIR = rf"{BASE_DIR}\input_bottom"
OUTPUT_DIR = rf"{BASE_DIR}\output_bottom"
TEMPLATE_DIR = rf"{BASE_DIR}\templates_bottom"

# A correctly oriented BOTTOM image; the layout below was measured on it and the
# templates are located on it at start-up (it is your reference_image.png)
REFERENCE_IMAGE = rf"{BASE_DIR}\templates_bottom\reference_bottom.png"

TEMPLATE_FILES = {
    "pin": "ball1.png",
    "triangle": "triangle.png",      # as in the canonical image (bottom-right corner)
    "box_left": "topbox_2.png",      # left white box, canonical
    "box_right": "topbox_1.png",     # right white box, canonical
    "gray_box": "target.png",        # gray box, canonical
}

IMAGE_EXTENSIONS = (".png", ".tif", ".tiff", ".bmp", ".jpg", ".jpeg")

# ============================================================
# SETTINGS
# ============================================================

PRE_BLUR_SIGMA = 1.0
PIN_CANDIDATE_MIN = 0.30          # pin template score to become a lattice candidate
LATTICE_TOL = 0.22                # max distance of a pin from its lattice node (in pitches)
MIN_LATTICE_PINS = 5              # fewer inliers -> fall back to the die square

ORIENT_SEARCH = 8                 # +- px (reference scale) when scoring the 4 rotations
FINAL_SEARCH = 10                 # +- px when locating each feature in the chosen frame
PIN_SEARCH = 12

# weights of the evidence when choosing the rotation
W_TRIANGLE, W_BOXES, W_GRAY = 0.35, 0.40, 0.25
EVIDENCE_BASE = 0.45              # match level that random die texture reaches; only the excess counts
ORIENT_MIN_MARGIN = 0.10          # below this the rotation is flagged as uncertain

# a feature counts as detected when its score reaches this and it lies within
# POSITION_TOL px of the layout prediction
MIN_SCORE = {"triangle": 0.45, "box_left": 0.40, "box_right": 0.40, "gray_box": 0.45, "pin": 0.35}
POSITION_TOL = 8.0

# The features never move on the unit, so by default their outline is drawn where the
# geometry (frame from pins + matched features) puts them. A damaged feature can pull a
# template match several px off, the geometry does not. "match" = use the matched position.
PLACE_FEATURES = "geometry"       # "geometry" or "match"

SAVE_CANONICAL = False            # also save deskewed + correctly rotated copies
DRAW_SEARCH_REGIONS = True
DISPLAY_STRETCH = True
SAVE_CSV = True
SAVE_JSON = True

# ============================================================
# REFERENCE LAYOUT (canonical, reference px, relative to the pin-grid centre, y down)
# measured on reference_image.png, pitch 108.46 px
# ============================================================

REF_PITCH = 108.46
PIN_RADIUS = 30.0
FEATURES = {
    #             centre            (w, h)      outline
    "box_left": ((-212.2, -110.2), (35, 74)),
    "box_right": ((211.8, -109.2), (33, 68)),
    "gray_box": ((212.3, -2.2), (32, 62)),
}
TRIANGLE = [(223.8, 179.3), (223.8, 221.3), (181.8, 221.3)]   # right angle at the middle vertex
TRIANGLE_CENTRE = tuple(np.mean(TRIANGLE, axis=0))
DIE_OFFSET = (-0.7, -4.7)          # die centre relative to the pin grid

COLORS = {"pin": (90, 220, 90), "pin_geo": (60, 130, 255), "triangle": (80, 80, 255),
          "box": (255, 170, 60), "gray_box": (60, 220, 255), "die": (200, 200, 200),
          "search": (120, 120, 60), "text": (255, 255, 255), "warn": (80, 80, 255)}

# ============================================================
# HELPERS
# ============================================================


def load_gray(path):
    img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(f"Cannot load image: {path}")
    if img.ndim == 3:
        img = cv2.cvtColor(img[..., :3], cv2.COLOR_BGR2GRAY)
    return img.astype(np.float32)


def stretch8(gray, lo=0.5, hi=99.8):
    a, b = np.percentile(gray, (lo, hi))
    return np.clip((gray - a) * 255.0 / max(1e-6, b - a), 0, 255).astype(np.uint8)


def blur(x):
    return cv2.GaussianBlur(x, (0, 0), PRE_BLUR_SIGMA) if PRE_BLUR_SIGMA > 0 else x


def rot(phi):
    c, s = math.cos(phi), math.sin(phi)
    return np.array([[c, -s], [s, c]])


def detect_die(gray):
    """Square fitted to the die: centre, side, angle (deg, in [-45, 45))."""
    u8 = cv2.GaussianBlur(stretch8(gray), (0, 0), 2)
    bg = np.percentile(u8, 2)
    surf = np.median(u8[u8.shape[0] // 4:3 * u8.shape[0] // 4, u8.shape[1] // 4:3 * u8.shape[1] // 4])
    m = (u8 > bg + 0.35 * (surf - bg)).astype(np.uint8) * 255
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, np.ones((7, 7), np.uint8))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    if n < 2:
        return None
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    cs, _ = cv2.findContours((lab == i).astype(np.uint8), cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    (cx, cy), (w, h), ang = cv2.minAreaRect(cv2.convexHull(max(cs, key=cv2.contourArea)))
    side = 0.5 * (w + h)
    ang = ((ang + 45.0) % 90.0) - 45.0
    return {"center": (cx, cy), "side": side, "angle": ang,
            "box": cv2.boxPoints(((cx, cy), (side, side), ang)).tolist()}


def local_maxima(score, min_dist, thr, max_n=60):
    k = max(3, int(min_dist) | 1)
    dil = cv2.dilate(score, cv2.getStructuringElement(cv2.MORPH_ELLIPSE, (k, k)))
    ys, xs = np.nonzero((score >= dil - 1e-6) & (score >= thr))
    order = np.argsort(-score[ys, xs])[:max_n]
    return [(int(xs[i]), int(ys[i]), float(score[ys[i], xs[i]])) for i in order]


def subpixel(res, x, y):
    dx = dy = 0.0
    h, w = res.shape
    if 0 < x < w - 1:
        l, c, r = res[y, x - 1], res[y, x], res[y, x + 1]
        d = l - 2 * c + r
        dx = float(np.clip(0.5 * (l - r) / d, -0.5, 0.5)) if abs(d) > 1e-9 else 0.0
    if 0 < y < h - 1:
        t, c, b = res[y - 1, x], res[y, x], res[y + 1, x]
        d = t - 2 * c + b
        dy = float(np.clip(0.5 * (t - b) / d, -0.5, 0.5)) if abs(d) > 1e-9 else 0.0
    return x + dx, y + dy


def match_at(img, tpl, tl_expected, search, mask=None):
    """Best match of tpl with its top-left within +-search of tl_expected."""
    th, tw = tpl.shape
    x0, y0 = int(round(tl_expected[0])) - search, int(round(tl_expected[1])) - search
    pad = search + max(th, tw)
    P = cv2.copyMakeBorder(img, pad, pad, pad, pad, cv2.BORDER_REPLICATE)
    win = P[y0 + pad:y0 + pad + th + 2 * search, x0 + pad:x0 + pad + tw + 2 * search]
    res = cv2.matchTemplate(win, tpl, cv2.TM_CCOEFF_NORMED, mask=mask)
    res = np.nan_to_num(res, nan=-1.0, posinf=-1.0, neginf=-1.0)
    _, mv, _, ml = cv2.minMaxLoc(res)
    px, py = subpixel(res, *ml)
    return float(mv), (x0 + px, y0 + py)


# ============================================================
# PIN LATTICE
# ============================================================

def pin_candidates(gray, pin_tpl, k):
    g = blur(gray)
    cands = []
    for s in (0.92, 1.0, 1.08):
        t = cv2.resize(pin_tpl, None, fx=k * s, fy=k * s, interpolation=cv2.INTER_AREA if k * s < 1 else cv2.INTER_CUBIC)
        if t.shape[0] >= g.shape[0] or t.shape[1] >= g.shape[1]:
            continue
        res = cv2.matchTemplate(g, blur(t), cv2.TM_CCOEFF_NORMED)
        h, w = t.shape
        for x, y, sc in local_maxima(res, 0.5 * REF_PITCH * k, PIN_CANDIDATE_MIN):
            px, py = subpixel(res, x, y)
            cands.append((px + (w - 1) / 2, py + (h - 1) / 2, sc))
    cands.sort(key=lambda c: -c[2])
    kept = []
    for c in cands:                                         # merge the three scales
        if all(math.hypot(c[0] - d[0], c[1] - d[1]) > 0.4 * REF_PITCH * k for d in kept):
            kept.append(c)
    return np.array(kept) if kept else np.zeros((0, 3))


def fit_lattice(cands, k, centre_guess):
    """Robust 4x4 lattice fit: returns centre, pitch, angle (rad, in [-45, 45) deg), inliers."""
    if len(cands) < 3:
        return None
    P, S = cands[:, :2], cands[:, 2]
    p0 = REF_PITCH * k
    # pitch and angle from neighbouring pairs
    d = P[None, :, :] - P[:, None, :]
    dist = np.hypot(d[..., 0], d[..., 1])
    i, j = np.nonzero((dist > 0.8 * p0) & (dist < 1.2 * p0))
    if len(i) < 2:
        return None
    pitch = float(np.median(dist[i, j]))
    ang = np.arctan2(d[i, j, 1], d[i, j, 0])
    w = S[i] * S[j]
    theta = float(np.angle(np.sum(w * np.exp(4j * ang))) / 4)     # 4-fold symmetric mean
    # lattice phase, then the 4x4 window that explains most candidates
    Rinv = rot(-theta)
    U = (P - centre_guess) @ Rinv.T / pitch
    phase = np.array([np.angle(np.sum(S * np.exp(2j * np.pi * U[:, a]))) / (2 * np.pi) for a in (0, 1)])
    best = None
    for ox in range(-3, 4):
        for oy in range(-3, 4):
            c = phase + 0.5 + np.array([ox, oy])                  # grid centre is half a pitch off a node
            rel = U - c
            node = np.clip(np.round(rel - 0.5) + 0.5, -1.5, 1.5)
            err = np.hypot(*(rel - node).T)
            inl = err < LATTICE_TOL
            score = S[inl].sum() - 0.5 * np.hypot(*c)              # prefer the window near the die centre
            if best is None or score > best[0]:
                best = (score, c, inl, node)
    _, c, inl, node = best
    if inl.sum() < 3:
        return None
    # least squares similarity fit on the inliers: X = C + a*u - b*v ; Y = Cy + b*u + a*v
    for _ in range(2):
        u, v = node[inl, 0], node[inl, 1]
        n = len(u)
        A = np.zeros((2 * n, 4))
        A[:n, 0], A[:n, 2], A[:n, 3] = 1, u, -v
        A[n:, 1], A[n:, 2], A[n:, 3] = 1, v, u
        y = np.r_[P[inl, 0], P[inl, 1]]
        sol = np.linalg.lstsq(A, y, rcond=None)[0]
        C, a, b = sol[:2], sol[2], sol[3]
        pitch, theta = math.hypot(a, b), math.atan2(b, a)
        U = (P - C) @ rot(-theta).T / pitch
        node = np.clip(np.round(U - 0.5) + 0.5, -1.5, 1.5)
        inl = np.hypot(*(U - node).T) < LATTICE_TOL
        tight = np.hypot(*(U - node).T) < 0.06               # final fit: only pins sitting on their node
        if tight.sum() >= 8:
            inl = tight
    res = (A @ sol - y).reshape(2, -1).T
    theta = ((math.degrees(theta) + 45) % 90 - 45)
    return {"center": (float(C[0]), float(C[1])), "pitch": pitch, "angle": math.radians(theta),
            "inliers": int(inl.sum()), "rms": float(np.sqrt((res ** 2).sum(1).mean()))}


# ============================================================
# REFERENCE FRAME AND CALIBRATION
# ============================================================

class Reference:
    """Everything measured once on the reference image."""

    def __init__(self, tpl_dir, ref_path):
        self.raw = {k: load_gray(Path(tpl_dir) / f) for k, f in TEMPLATE_FILES.items()}
        ref = load_gray(ref_path)
        self.shape = ref.shape
        self.levels = np.percentile(ref, (1, 99))           # input images are mapped to these levels
        die = detect_die(ref)
        cands = pin_candidates(ref, self.raw["pin"], 1.0)
        lat = fit_lattice(cands, 1.0, np.array(die["center"]) if die else np.array(ref.shape[::-1]) / 2)
        if lat is None or lat["inliers"] < 12:
            raise RuntimeError("Calibration: pin lattice not found in the reference image")
        self.C = np.array(lat["center"])
        self.pitch = lat["pitch"]
        self.angle = lat["angle"]
        self.die_side = die["side"] if die else ref.shape[1] * 0.96
        self.tpl = {k: blur(v) for k, v in self.raw.items()}
        self.box_mask = {k: self._outline_mask(self.raw[k]) for k in ("box_left", "box_right")}
        canon = blur(ref)
        self.tl, self.calib = {}, {}
        for name in ("triangle", "box_left", "box_right", "gray_box"):
            tpl = self.tpl[name]
            exp_c = self.centre(name)
            tl0 = (exp_c[0] - (tpl.shape[1] - 1) / 2, exp_c[1] - (tpl.shape[0] - 1) / 2)
            sc, tl = match_at(canon, tpl, tl0, 25, self.box_mask.get(name))
            self.tl[name], self.calib[name] = tl, sc
        # pin template: offset of its centre from the lattice node
        offs = []
        for node in self.pin_nodes():
            t = self.tpl["pin"]
            tl0 = (node[0] - (t.shape[1] - 1) / 2, node[1] - (t.shape[0] - 1) / 2)
            sc, tl = match_at(canon, t, tl0, PIN_SEARCH)
            offs.append((tl[0] - tl0[0], tl[1] - tl0[1]))
        self.pin_tl_offset = np.median(np.array(offs), axis=0)
        self.white_ref = {name: self.whiteness(canon, name) for name in ("triangle", "box_left", "box_right")}
        print("Calibration on reference image:")
        print(f"  pin lattice: centre ({self.C[0]:.1f}, {self.C[1]:.1f}), pitch {self.pitch:.2f} px, "
              f"tilt {math.degrees(self.angle):.2f} deg, {lat['inliers']} pins")
        for name, sc in self.calib.items():
            flag = "" if sc >= 0.8 else "   <-- low, check this template"
            print(f"  {name:9s} template score {sc:.3f}{flag}")

    @staticmethod
    def _outline_mask(tpl):
        """Mask = a band around the white rectangle's border (the symbols inside are ignored)."""
        u8 = cv2.normalize(tpl, None, 0, 255, cv2.NORM_MINMAX).astype(np.uint8)
        _, m = cv2.threshold(cv2.GaussianBlur(u8, (0, 0), 1), 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
        k = max(5, int(0.4 * min(tpl.shape)) | 1)
        m = cv2.morphologyEx(m, cv2.MORPH_CLOSE, np.ones((k, k), np.uint8))
        n, lab, st, _ = cv2.connectedComponentsWithStats(m)
        i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
        x, y, w, h = st[i][:4]
        band = np.zeros_like(u8)
        cv2.rectangle(band, (x, y), (x + w - 1, y + h - 1), 255, 7)
        return (band > 0).astype(np.float32)

    def centre(self, name):
        off = TRIANGLE_CENTRE if name == "triangle" else FEATURES[name][0]
        return self.C + rot(self.angle) @ np.array(off)

    def polygon(self, name):
        if name == "triangle":
            pts = TRIANGLE
        else:
            (cx, cy), (w, h) = FEATURES[name]
            pts = [(cx - w / 2, cy - h / 2), (cx + w / 2, cy - h / 2), (cx + w / 2, cy + h / 2), (cx - w / 2, cy + h / 2)]
        return [tuple(self.C + rot(self.angle) @ np.array(p)) for p in pts]

    def pin_nodes(self):
        R = rot(self.angle)
        return [self.C + R @ (np.array([c - 1.5, r - 1.5]) * self.pitch) for r in range(4) for c in range(4)]

    def whiteness(self, canon, name):
        """How much brighter the feature is than its surroundings (robust to partial damage)."""
        m = np.zeros(canon.shape, np.uint8)
        cv2.fillPoly(m, [np.round(np.array(self.polygon(name))).astype(np.int32)], 1)
        ring = cv2.dilate(m, np.ones((15, 15), np.uint8)) - cv2.dilate(m, np.ones((5, 5), np.uint8))
        inner = cv2.erode(m, np.ones((3, 3), np.uint8))
        if inner.sum() < 10 or ring.sum() < 10:
            return 0.0
        return float(np.percentile(canon[inner > 0], 70) - np.median(canon[ring > 0]))

    def warp(self, gray, centre, pitch, angle, q, fill):
        """Image -> reference frame for rotation hypothesis q (image = canonical rotated q*90 CW)."""
        s = pitch / self.pitch
        A = s * rot(angle - self.angle + q * math.pi / 2)
        t = np.array(centre) - A @ self.C
        M = np.hstack([A, t[:, None]])                      # maps reference -> image
        canon = cv2.warpAffine(gray, M, (self.shape[1], self.shape[0]),
                               flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                               borderMode=cv2.BORDER_CONSTANT, borderValue=float(fill))
        return canon, M


def to_image(M, pts):
    pts = np.atleast_2d(np.array(pts, float))
    return (pts @ M[:, :2].T + M[:, 2]).tolist()


# ============================================================
# DETECTION
# ============================================================

def score_frame(ref, canon, search):
    """Evidence for triangle, boxes and gray box in a reference-frame image."""
    out = {}
    for name in ("triangle", "box_left", "box_right", "gray_box"):
        sc, tl = match_at(canon, ref.tpl[name], ref.tl[name], search, ref.box_mask.get(name))
        white = None
        if name != "gray_box":
            white = float(np.clip(ref.whiteness(canon, name) / max(1.0, ref.white_ref[name]), -0.5, 1.5))
        out[name] = {"score": sc, "tl": tl, "white": white}
    return out


def combined(ev):
    """Orientation evidence. Only clearly-above-background matches count, so one strong
    feature outweighs several mediocre random matches (destroyed features score ~0)."""
    def gain(v):
        return max(0.0, v - EVIDENCE_BASE) / (1.0 - EVIDENCE_BASE)
    tri = gain(0.7 * ev["triangle"]["score"] + 0.3 * min(1.0, ev["triangle"]["white"]))
    box = np.mean([gain(0.7 * ev[b]["score"] + 0.3 * min(1.0, ev[b]["white"])) for b in ("box_left", "box_right")])
    return W_TRIANGLE * tri + W_BOXES * box + W_GRAY * gain(ev["gray_box"]["score"])


def locate(ref, gray, M, lat, wide=1.0):
    """Step 3: every feature and pin in a small ROI of the reference frame given by M."""
    canon_raw = cv2.warpAffine(gray, M, (ref.shape[1], ref.shape[0]), flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP,
                               borderMode=cv2.BORDER_CONSTANT, borderValue=float(np.percentile(gray, 1)))
    canon = blur(canon_raw)
    warnings = []
    ev = score_frame(ref, canon, int(FINAL_SEARCH * wide))
    tol = POSITION_TOL * wide
    feats, shifts = {}, {}
    for name in ("triangle", "box_left", "box_right", "gray_box"):
        e = ev[name]
        shift = np.array(e["tl"]) - np.array(ref.tl[name])
        ok = e["score"] >= MIN_SCORE[name] and np.hypot(*shift) <= tol
        if name != "gray_box" and e["white"] is not None and e["white"] < 0.3:
            ok = False                                        # not white enough to be the feature
        use_shift = ok and PLACE_FEATURES == "match"
        poly = np.array(ref.polygon(name)) + (shift if use_shift else 0)
        if ok:
            shifts[name] = shift
        feats[name] = {"status": "matched" if ok else "weak", "score": round(e["score"], 3),
                       "white": None if e["white"] is None else round(e["white"], 2),
                       "offset_px": [round(float(v), 1) for v in shift],
                       "polygon": to_image(M, poly), "center": to_image(M, poly.mean(axis=0))[0]}
        if not ok:
            warnings.append(f"{name} weak (damaged or covered?)")
    pins = []
    t = ref.tpl["pin"]
    for idx, node in enumerate(ref.pin_nodes()):
        tl0 = (node[0] - (t.shape[1] - 1) / 2 + ref.pin_tl_offset[0], node[1] - (t.shape[0] - 1) / 2 + ref.pin_tl_offset[1])
        sc, tl = match_at(canon, t, tl0, int(PIN_SEARCH * wide))
        shift = np.array(tl) - np.array(tl0)
        ok = sc >= MIN_SCORE["pin"] and np.hypot(*shift) <= tol
        c = node + (shift if ok else 0)
        pins.append({"row": idx // 4, "col": idx % 4, "status": "matched" if ok else "weak",
                     "score": round(sc, 3), "center": to_image(M, c)[0],
                     "radius": PIN_RADIUS * lat["pitch"] / ref.pitch, "_shift": shift if ok else None,
                     "_node": node})
    n_weak = sum(p["status"] == "weak" for p in pins)
    if n_weak:
        warnings.append(f"{n_weak} pin(s) weak")
    return feats, pins, shifts, warnings, canon_raw


def refine_frame(ref, M, feats_shifts, pins):
    """Correct the frame with what was actually found (used when the pin lattice was not usable)."""
    src, dst = [], []
    for name, sh in feats_shifts.items():
        c = ref.centre(name)
        src.append(c)
        dst.append(c + sh)
    for p in pins:
        if p["_shift"] is not None:
            src.append(p["_node"])
            dst.append(p["_node"] + p["_shift"])
    if len(src) < 2:
        return M
    A, inl = cv2.estimateAffinePartial2D(np.float32(src), np.float32(dst), method=cv2.RANSAC,
                                         ransacReprojThreshold=3.0)
    if A is None or (inl is not None and inl.sum() < 6):
        return M
    scale = math.hypot(A[0, 0], A[1, 0])
    angle = math.degrees(math.atan2(A[1, 0], A[0, 0]))
    move = np.hypot(*(A[:, :2] @ ref.C + A[:, 2] - ref.C))
    if abs(scale - 1) > 0.02 or abs(angle) > 1.5 or move > 3 * POSITION_TOL:
        return M                                              # implausible correction: keep the frame
    A3 = np.vstack([A, [0, 0, 1]])
    M3 = np.vstack([M, [0, 0, 1]])
    return (M3 @ A3)[:2]


def detect(gray, ref):
    # same intensity scale as the reference (8/16-bit, exposure), so contrast tests are comparable
    original = gray
    lo, hi = np.percentile(gray, (1, 99))
    gray = ((gray - lo) * (ref.levels[1] - ref.levels[0]) / max(1e-6, hi - lo) + ref.levels[0]).astype(np.float32)
    H, W = gray.shape
    warnings = []
    out = {"warnings": warnings}

    # 0. die
    die = detect_die(gray)
    out["die"] = die
    if die is not None:
        k = float(np.clip(die["side"] / ref.die_side, 0.7, 1.4))
        guess = np.array(die["center"])
    else:
        k, guess = min(H, W) / min(ref.shape), np.array([W / 2, H / 2])
        warnings.append("die not found")

    # 1. pin lattice
    cands = pin_candidates(gray, ref.raw["pin"], k)
    lat = fit_lattice(cands, k, guess)
    if lat is None or lat["inliers"] < MIN_LATTICE_PINS:
        warnings.append("pin lattice weak: frame from die square")
        if die is None:
            lat = {"center": tuple(guess), "pitch": ref.pitch * k, "angle": 0.0, "inliers": 0, "rms": -1}
        else:
            ang = math.radians(die["angle"])
            lat = {"center": tuple(np.array(die["center"]) - k * np.array(DIE_OFFSET)),
                   "pitch": ref.pitch * k, "angle": ang, "inliers": 0, "rms": -1}
        lattice_ok = False
    else:
        lattice_ok = True
    out["lattice"] = lat
    fill = float(np.percentile(gray, 1))

    # 2. the four rotations
    hyps = []
    for q in range(4):
        canon, M = ref.warp(gray, lat["center"], lat["pitch"], lat["angle"], q, fill)
        ev = score_frame(ref, blur(canon), ORIENT_SEARCH)
        hyps.append({"q": q, "score": combined(ev), "ev": ev, "M": M, "canon": canon})
    hyps.sort(key=lambda h: -h["score"])
    best = hyps[0]
    margin = best["score"] - hyps[1]["score"]
    if margin < ORIENT_MIN_MARGIN:
        warnings.append(f"rotation uncertain (margin {margin:.2f}, runner-up {90 * hyps[1]['q']} deg)")
    q, M = best["q"], best["M"]
    out.update(rotation_cw=90 * q, orientation_margin=margin,
               orientation_scores={90 * h["q"]: round(h["score"], 3) for h in hyps})
    tilt = math.degrees(lat["angle"])
    out["tilt_deg"], out["scale"] = tilt, lat["pitch"] / ref.pitch

    # 3. features in the chosen frame
    # the frame is corrected with everything that was found (pins + features), then the
    # final search is done; from the die alone the frame is rough, so it gets two wider passes
    for wide in ((1.5,) if lattice_ok else (3.0, 1.5)):
        _, pins_w, shifts_w, _, _ = locate(ref, gray, M, lat, wide)
        M = refine_frame(ref, M, shifts_w, pins_w)
    feats, pins, shifts, w3, _ = locate(ref, gray, M, lat)
    warnings += w3
    for p in pins:
        p.pop("_shift"), p.pop("_node")
    out["features"], out["pins"] = feats, pins
    # frame: maps layout coordinates (canonical, reference px, relative to the pin-grid centre)
    # to image px; used by crop scripts to cut straightened, correctly rotated ROIs
    A = M[:, :2] @ rot(ref.angle)
    out["frame"] = np.hstack([A, (M[:, :2] @ ref.C + M[:, 2])[:, None]]).tolist()
    out["lattice_ok"] = lattice_ok
    out["canonical"] = cv2.warpAffine(original, M, (ref.shape[1], ref.shape[0]),       # original intensities
                                      flags=cv2.INTER_LINEAR | cv2.WARP_INVERSE_MAP, borderMode=cv2.BORDER_REPLICATE)
    out["searches"] = {name: to_image(M, [np.array(ref.tl[name]) - FINAL_SEARCH,
                                          np.array(ref.tl[name]) + np.array(ref.tpl[name].shape[::-1]) + FINAL_SEARCH])
                       for name in ("triangle", "box_left", "box_right", "gray_box")}
    return out


# ============================================================
# DRAWING
# ============================================================

def dashed(img, pts, color, th=1, dash=8, gap=6, closed=True):
    pts = [np.array(p, float) for p in pts] + ([np.array(pts[0], float)] if closed else [])
    for a, b in zip(pts[:-1], pts[1:]):
        L = np.linalg.norm(b - a)
        if L < 1:
            continue
        d, t = (b - a) / L, 0.0
        while t < L:
            e = min(t + dash, L)
            cv2.line(img, tuple(np.round(a + d * t).astype(int)), tuple(np.round(a + d * e).astype(int)), color, th, cv2.LINE_AA)
            t = e + gap


def draw(gray, res, name):
    base = stretch8(gray) if DISPLAY_STRETCH else np.clip(gray, 0, 255).astype(np.uint8)
    f = 2 if max(gray.shape) < 900 else 1                      # small images are drawn 2x for readability
    img = cv2.resize(cv2.cvtColor(base, cv2.COLOR_GRAY2BGR), None, fx=f, fy=f, interpolation=cv2.INTER_CUBIC)
    S = lambda pts: (np.array(pts) * f).tolist()
    fs = 0.55

    if res["die"] is not None:
        dashed(img, S(res["die"]["box"]), COLORS["die"], 1, 12, 8)
    if DRAW_SEARCH_REGIONS:
        for (x0, y0), (x1, y1) in res["searches"].values():
            # search windows are rectangles in the reference frame; draw their image bounding box
            dashed(img, S([(x0, y0), (x1, y0), (x1, y1), (x0, y1)]), COLORS["search"], 1, 5, 5)

    for p in res["pins"]:
        c = tuple(np.round(np.array(p["center"]) * f).astype(int))
        r = int(round(p["radius"] * f))
        if p["status"] == "matched":
            cv2.circle(img, c, r, COLORS["pin"], 2, cv2.LINE_AA)
        else:
            pts = [(c[0] + r * math.cos(a), c[1] + r * math.sin(a)) for a in np.linspace(0, 2 * np.pi, 40, endpoint=False)]
            dashed(img, pts, COLORS["pin_geo"], 2, 6, 5)

    labels = {"triangle": "TRIANGLE", "box_left": "BOX L", "box_right": "BOX R", "gray_box": "GRAY BOX"}
    for key, ft in res["features"].items():
        color = COLORS["triangle"] if key == "triangle" else COLORS["gray_box"] if key == "gray_box" else COLORS["box"]
        pts = S(ft["polygon"])
        if ft["status"] == "matched":
            cv2.polylines(img, [np.round(np.array(pts)).astype(np.int32)], True, color, 2, cv2.LINE_AA)
        else:
            dashed(img, pts, color, 2)
        cx, cy = np.mean(pts, axis=0)
        txt = f"{labels[key]} {ft['score']:.2f}" + ("" if ft["status"] == "matched" else " WEAK")
        tx = int(min(max(cx - 60, 4), img.shape[1] - 170))
        ty = int(cy + (60 if cy < img.shape[0] / 2 else -50))
        cv2.putText(img, txt, (tx, ty), cv2.FONT_HERSHEY_SIMPLEX, fs, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(img, txt, (tx, ty), cv2.FONT_HERSHEY_SIMPLEX, fs, color, 1, cv2.LINE_AA)

    lines = [name, f"rotation {res['rotation_cw']} deg CW | tilt {res['tilt_deg']:.1f} deg | "
                   f"scale {res['scale']:.3f} | margin {res['orientation_margin']:.2f}"]
    y = 22
    for ln in lines:
        cv2.putText(img, ln, (8, y), cv2.FONT_HERSHEY_SIMPLEX, fs, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(img, ln, (8, y), cv2.FONT_HERSHEY_SIMPLEX, fs, COLORS["text"], 1, cv2.LINE_AA)
        y += 22
    for w in res["warnings"]:
        cv2.putText(img, "! " + w, (8, y), cv2.FONT_HERSHEY_SIMPLEX, fs, (0, 0, 0), 4, cv2.LINE_AA)
        cv2.putText(img, "! " + w, (8, y), cv2.FONT_HERSHEY_SIMPLEX, fs, COLORS["warn"], 1, cv2.LINE_AA)
        y += 22
    return img


# ============================================================
# MAIN
# ============================================================

def r2(v):
    if isinstance(v, dict):
        return {k: r2(x) for k, x in v.items()}
    if isinstance(v, (list, tuple)):
        return [r2(x) for x in v]
    if isinstance(v, (float, np.floating)):
        return round(float(v), 2)
    if isinstance(v, np.integer):
        return int(v)
    return v


def main():
    in_dir, out_dir = Path(INPUT_DIR), Path(OUTPUT_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)
    if SAVE_CANONICAL:
        (out_dir / "canonical").mkdir(exist_ok=True)
    ref = Reference(TEMPLATE_DIR, REFERENCE_IMAGE)

    files = sorted(p for p in in_dir.iterdir() if p.suffix.lower() in IMAGE_EXTENSIONS)
    print(f"\n{len(files)} images in {in_dir}")
    rows, records = [], []
    for i, path in enumerate(files, 1):
        t0 = time.time()
        try:
            gray = load_gray(path)
            res = detect(gray, ref)
            cv2.imwrite(str(out_dir / f"{path.stem}_bottom.png"), draw(gray, res, path.name))
            if SAVE_CANONICAL:
                cv2.imwrite(str(out_dir / "canonical" / f"{path.stem}_canonical.png"),
                            np.clip(res["canonical"], 0, 65535).astype(np.uint16 if gray.max() > 255 else np.uint8))
        except Exception as exc:
            print(f"[{i}/{len(files)}] {path.name}: ERROR {exc}")
            rows.append({"file": path.name, "error": str(exc)})
            continue
        F, lat = res["features"], res["lattice"]
        row = {"file": path.name, "rotation_cw_deg": res["rotation_cw"],
               "to_canonical": {0: "none", 90: "rotate 90 CCW", 180: "rotate 180", 270: "rotate 90 CW"}[res["rotation_cw"]],
               "orientation_margin": round(res["orientation_margin"], 3),
               "tilt_deg": round(res["tilt_deg"], 2), "scale": round(res["scale"], 4),
               "grid_x": round(lat["center"][0], 1), "grid_y": round(lat["center"][1], 1),
               "lattice_pins": lat["inliers"], "lattice_rms": round(lat["rms"], 2)}
        for name in ("triangle", "box_left", "box_right", "gray_box"):
            row[f"{name}_status"] = F[name]["status"]
            row[f"{name}_score"] = F[name]["score"]
            if F[name]["white"] is not None:
                row[f"{name}_white"] = F[name]["white"]
        row["pins_matched"] = sum(p["status"] == "matched" for p in res["pins"])
        row["pin_scores"] = " ".join(f"{p['score']:.2f}" for p in res["pins"])
        row["warnings"] = "; ".join(res["warnings"])
        row["error"] = ""
        rows.append(row)
        records.append(r2({"file": path.name, "rotation_cw_deg": res["rotation_cw"], "tilt_deg": res["tilt_deg"],
                           "scale": res["scale"], "lattice": lat, "die": res["die"], "features": F,
                           "pins": res["pins"],
                           "orientation_scores": res["orientation_scores"],
                           "warnings": res["warnings"]}))
        records[-1]["frame"] = [[round(float(v), 6) for v in row_] for row_ in res["frame"]]   # full precision
        flag = "  ! " + "; ".join(res["warnings"]) if res["warnings"] else ""
        print(f"[{i}/{len(files)}] {path.name}: rot {res['rotation_cw']:3d}  tilt {res['tilt_deg']:+.1f}  "
              f"pins {row['pins_matched']}/16  {time.time() - t0:.2f}s{flag}")

    if SAVE_CSV and rows:
        keys = list(dict.fromkeys(k for r in rows for k in r))
        with open(out_dir / "bottom_results.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(rows)
    if SAVE_JSON:
        with open(out_dir / "bottom_results.json", "w") as f:
            json.dump(records, f, indent=1)
    print(f"\nDone. Results in {out_dir}")


if __name__ == "__main__":
    main()
