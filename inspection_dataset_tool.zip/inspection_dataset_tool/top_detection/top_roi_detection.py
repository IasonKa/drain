"""
TOP-ROI-DETECTION
=================

Detects the four ROIs on TOP images of the lens unit and writes annotated copies.

Canonical orientation (as in the reference image):
    label on the top-left, corner marks on the top-right and bottom-left,
    inner area = the large octagon centred on the lens (not the rings).

Per image:
    0. Fit a square to the die            -> coarse centre and scale
    1. Find the lens eye near the centre  -> precise centre
    2. Test the two corner diagonals (TR+BL vs TL+BR), each corner with its own
       rotation of the corner template, and keep the diagonal that fits best
       and is geometrically consistent with the eye.
    3. Test the two label corners allowed by that diagonal, each with its own
       rotation of the label template. If matching is weak, fall back to a
       label-versus-blank texture test.
    4. Safety net: every ROI is predicted from the reference layout (scaled).
       A detection is kept only when it is good and agrees with the prediction,
       otherwise the predicted position is used, so every image is annotated.

Outputs (in OUTPUT_DIR): annotated copies, roi_results.csv, roi_results.json.
"""

import csv
import json
import math
import time
from pathlib import Path

import cv2
import numpy as np

# ============================================================
# PATHS  (edit these)
# ============================================================

BASE_DIR = r"C:\Users\laka\software\Automated_Inspection\detect_claude"

INPUT_DIR = rf"{BASE_DIR}\input_top"            # folder with TOP images
OUTPUT_DIR = rf"{BASE_DIR}\output_top_roi"      # annotated copies + results
TEMPLATE_DIR = rf"{BASE_DIR}\templates"          # lens / inner / corner / label crops

# One correctly oriented TOP image (label top-left, marks top-right and
# bottom-left). The ROI layout below was measured on it; the templates are
# calibrated against it at start-up, so their crop margins and scale do not matter.
REFERENCE_IMAGE = rf"{BASE_DIR}\templates\reference_top.png"

TEMPLATE_FILES = {
    "lens": "lens.png",      # the eye: small crop of the centre of the rings
    "inner": "inner.png",    # the octagon inner area
    "corner": "corner.png",  # ONE corner mark, rotated in code for each corner
    "label": "label.png",    # ONE label, rotated in code for each corner
}

# Which image corner each single template was cropped from (TL, TR, BR, BL).
# Your corner.png shows the mark as it sits in the top-left corner and your
# label.png (upright text, R on top) is the label as it sits in the top-right.
CORNER_TEMPLATE_AT = "TL"
LABEL_TEMPLATE_AT = "TR"

IMAGE_EXTENSIONS = (".png", ".tif", ".tiff", ".bmp", ".jpg", ".jpeg")

# ============================================================
# MATCHING SETTINGS
# ============================================================

MATCH_FEATURE = "both"        # "intensity", "gradient" or "both" (average of the two)
PRE_BLUR_SIGMA = 1.2           # denoising before matching (applied to image and templates)

# Scale search around the current scale estimate (1.0 = reference image scale)
SCALES_COARSE = (0.96, 0.98, 1.00, 1.02, 1.04)
SCALES_FINE = (0.99, 1.00, 1.01)

# Search windows, as a fraction of the die side (reference die ~785 px)
LENS_SEARCH_FRAC = 0.10        # +- around the die centre
CORNER_SEARCH_FRAC = 0.05      # +- around the expected corner mark position
LABEL_SEARCH_FRAC = 0.04       # +- around the expected label position
INNER_SEARCH_FRAC = 0.02       # +- around the eye

# Acceptance thresholds (normalised correlation, 1.0 = perfect)
LENS_MIN_SCORE = 0.45
CORNER_MIN_SCORE = 0.40
LABEL_MIN_SCORE = 0.30
LABEL_STRONG_SCORE = 0.55     # a label match this good is trusted without the blank test
INNER_MIN_SCORE = 0.40

DIAGONAL_MIN_MARGIN = 0.10     # below this the diagonal choice is flagged
LABEL_MIN_MARGIN = 0.10        # template lead needed over the other label corner
BLANK_MIN_RATIO = 1.50         # label texture / blank texture needed to trust the blank test
GEOMETRY_WEIGHT = 4.0          # penalty weight for marks that are not symmetric about the eye
POSITION_TOL_FRAC = 0.015      # max distance detection <-> prediction (fraction of die side)

# ============================================================
# OUTPUT SETTINGS
# ============================================================

DRAW_SEARCH_REGIONS = True     # dim dashed boxes = where each template was searched
DRAW_DIE_SQUARE = True
DISPLAY_STRETCH = True         # contrast-stretch the annotated copy so ROIs are visible
SAVE_CSV = True
SAVE_JSON = True

# ============================================================
# REFERENCE LAYOUT (canonical orientation, reference pixels, y down)
# Measured on Rc01Cc01 and Rc01Cc04, relative to the centre of the eye.
# Both units agreed within ~1-2 px.
# ============================================================

REF_MARK_OFFSET = 298.5                  # |dx| = |dy| of each corner mark centre
REF_MARK_SIZE = (133.0, 133.0)           # corner mark box (w, h)
REF_LABEL_OFFSET = (-305.7, -317.6)      # label box centre
REF_LABEL_SIZE = (101.0, 79.0)           # label box (w, h), canonical orientation
REF_INNER_OFFSET = (0.3, -1.3)           # octagon centre
REF_INNER_SIZE = 540.0                   # octagon width = height
REF_INNER_CHAMFER = 80.0                 # length of each 45 deg corner cut (along x and y)
REF_MARK_DIAGONAL = 2.0 * math.sqrt(2.0) * REF_MARK_OFFSET   # distance TR mark <-> BL mark

# ============================================================
# CONSTANTS
# ============================================================

CORNERS = ("TL", "TR", "BR", "BL")       # clockwise
CORNER_SIGN = {"TL": (-1, -1), "TR": (1, -1), "BR": (1, 1), "BL": (-1, 1)}
DIAGONALS = {"TR-BL": ("TR", "BL"), "TL-BR": ("TL", "BR")}
LABEL_CORNERS_FOR = {"TR-BL": ("TL", "BR"), "TL-BR": ("TR", "BL")}

COLORS = {                               # BGR
    "inner": (90, 220, 90),
    "corner": (60, 170, 255),
    "label": (230, 120, 230),
    "eye": (255, 230, 60),
    "die": (200, 200, 200),
    "search": (120, 120, 60),
    "text": (255, 255, 255),
    "warn": (80, 80, 255),
}


# ============================================================
# SMALL HELPERS
# ============================================================

def corner_index(name):
    return CORNERS.index(name)


def rotate_vec(v, q):
    """Rotate (dx, dy) by q * 90 deg clockwise (image coordinates, y down)."""
    x, y = v
    for _ in range(q % 4):
        x, y = -y, x
    return x, y


def rotate_point(p, q, shape):
    """Where pixel p of an image with `shape` lands after rotating that image q*90 deg CW."""
    h, w = shape[:2]
    x, y = p
    q %= 4
    if q == 0:
        return x, y
    if q == 1:
        return h - 1 - y, x
    if q == 2:
        return w - 1 - x, h - 1 - y
    return y, w - 1 - x


def rotate_img(img, q):
    q %= 4
    if q == 0:
        return img
    code = {1: cv2.ROTATE_90_CLOCKWISE, 2: cv2.ROTATE_180, 3: cv2.ROTATE_90_COUNTERCLOCKWISE}[q]
    return cv2.rotate(img, code)


def load_gray(path):
    img = cv2.imread(str(path), cv2.IMREAD_UNCHANGED)
    if img is None:
        raise FileNotFoundError(f"Cannot load image: {path}")
    if img.ndim == 3:
        if img.shape[2] == 4:
            img = img[..., :3]
        img = cv2.cvtColor(img, cv2.COLOR_BGR2GRAY)
    return img.astype(np.float32)


def to_uint8_stretch(gray, lo=0.5, hi=99.5):
    a, b = np.percentile(gray, (lo, hi))
    if b <= a:
        b = a + 1.0
    return np.clip((gray - a) * 255.0 / (b - a), 0, 255).astype(np.uint8)


def to_uint8_plain(gray):
    if gray.max() > 255:
        return np.clip(gray / 257.0, 0, 255).astype(np.uint8)
    return np.clip(gray, 0, 255).astype(np.uint8)


def resize(img, f):
    h, w = img.shape[:2]
    nw, nh = max(3, int(round(w * f))), max(3, int(round(h * f)))
    interp = cv2.INTER_AREA if f < 1 else cv2.INTER_CUBIC
    return cv2.resize(img, (nw, nh), interpolation=interp)


def feature_maps(gray):
    """Feature images used for matching (same function for images and templates)."""
    b = cv2.GaussianBlur(gray, (0, 0), PRE_BLUR_SIGMA) if PRE_BLUR_SIGMA > 0 else gray
    maps = []
    if MATCH_FEATURE in ("intensity", "both"):
        maps.append(b)
    if MATCH_FEATURE in ("gradient", "both"):
        gx = cv2.Sobel(b, cv2.CV_32F, 1, 0, ksize=3)
        gy = cv2.Sobel(b, cv2.CV_32F, 0, 1, ksize=3)
        maps.append(cv2.magnitude(gx, gy))
    return maps


def subpixel_peak(res, loc):
    """Quadratic refinement of a correlation peak."""
    x, y = loc
    dx = dy = 0.0
    h, w = res.shape
    if 0 < x < w - 1:
        l, c, r = res[y, x - 1], res[y, x], res[y, x + 1]
        den = l - 2 * c + r
        if abs(den) > 1e-9:
            dx = float(np.clip(0.5 * (l - r) / den, -0.5, 0.5))
    if 0 < y < h - 1:
        t, c, b = res[y - 1, x], res[y, x], res[y + 1, x]
        den = t - 2 * c + b
        if abs(den) > 1e-9:
            dy = float(np.clip(0.5 * (t - b) / den, -0.5, 0.5))
    return x + dx, y + dy


# ============================================================
# DIE SQUARE
# ============================================================

def detect_die(gray):
    """Fit a square to the die (the bright unit on the dark background)."""
    u8 = to_uint8_stretch(gray, 0.5, 99.5)
    u8 = cv2.GaussianBlur(u8, (0, 0), 2)
    _, m = cv2.threshold(u8, 0, 255, cv2.THRESH_BINARY + cv2.THRESH_OTSU)
    k = max(3, int(0.012 * min(gray.shape)) | 1)
    m = cv2.morphologyEx(m, cv2.MORPH_OPEN, cv2.getStructuringElement(cv2.MORPH_RECT, (k, k)))
    n, lab, st, _ = cv2.connectedComponentsWithStats(m)
    if n < 2:
        return None
    i = 1 + int(np.argmax(st[1:, cv2.CC_STAT_AREA]))
    comp = (lab == i).astype(np.uint8)
    cs, _ = cv2.findContours(comp, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_NONE)
    hull = cv2.convexHull(max(cs, key=cv2.contourArea))   # bridges chipped edges
    (cx, cy), (w, h), ang = cv2.minAreaRect(hull)
    side = 0.5 * (w + h)
    if not (0.3 * min(gray.shape) < side < 1.05 * max(gray.shape)):
        return None
    ang = ((ang + 45.0) % 90.0) - 45.0                    # tilt in [-45, 45)
    box = cv2.boxPoints(((cx, cy), (side, side), ang))
    return {"center": (float(cx), float(cy)), "side": float(side), "angle": float(ang),
            "aspect": float(max(w, h) / max(1.0, min(w, h))), "box": box.tolist()}


# ============================================================
# TEMPLATE MATCHING
# ============================================================

class Matcher:
    """Matches templates inside windows of one (padded) image."""

    def __init__(self, gray, pad):
        self.pad = int(pad)
        padded = cv2.copyMakeBorder(gray, self.pad, self.pad, self.pad, self.pad, cv2.BORDER_REPLICATE)
        self.maps = feature_maps(padded)

    def match(self, tpl_gray, anchor, expected, margin):
        """Best match of tpl_gray whose anchor point lies within +-margin of `expected`.

        Returns score, anchor position in image coordinates and the scanned window.
        """
        th, tw = tpl_gray.shape
        ex, ey = expected
        ax, ay = anchor
        x0 = int(math.floor(ex - ax - margin)) + self.pad
        y0 = int(math.floor(ey - ay - margin)) + self.pad
        x1 = int(math.ceil(ex - ax + margin)) + tw + self.pad
        y1 = int(math.ceil(ey - ay + margin)) + th + self.pad
        H, W = self.maps[0].shape
        x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W, x1), min(H, y1)
        window = (x0 - self.pad, y0 - self.pad, x1 - self.pad, y1 - self.pad)
        if x1 - x0 < tw or y1 - y0 < th:
            return {"score": -1.0, "pos": (ex, ey), "window": window}
        res = None
        for fmap, tmap in zip(self.maps, feature_maps(tpl_gray)):
            r = cv2.matchTemplate(fmap[y0:y1, x0:x1], tmap, cv2.TM_CCOEFF_NORMED)
            res = r if res is None else res + r
        res /= len(self.maps)
        _, mv, _, ml = cv2.minMaxLoc(res)
        px, py = subpixel_peak(res, ml)
        pos = (x0 - self.pad + px + ax, y0 - self.pad + py + ay)
        return {"score": float(mv), "pos": pos, "window": window}


class Template:
    """A template normalised to reference scale, with an anchor = ROI centre in template pixels."""

    def __init__(self, gray, at_corner="TL"):
        self.raw = gray
        self.at = at_corner
        self.scale = 1.0          # raw -> reference scale factor (set by calibration)
        self.norm = gray
        self.anchor = ((gray.shape[1] - 1) / 2.0, (gray.shape[0] - 1) / 2.0)
        self.calib_score = None

    def variant(self, k, corner=None):
        """Template at image scale k, rotated to how it looks at `corner`."""
        img = resize(self.norm, k)
        fx = img.shape[1] / self.norm.shape[1]
        fy = img.shape[0] / self.norm.shape[0]
        anchor = (self.anchor[0] * fx, self.anchor[1] * fy)
        if corner is not None:
            q = corner_index(corner) - corner_index(self.at)
            anchor = rotate_point(anchor, q, img.shape)
            img = rotate_img(img, q)
        return img, anchor

    def best_over_scales(self, matcher, expected, margin, k, scales, corner=None):
        best = None
        for s in scales:
            img, anchor = self.variant(k * s, corner)
            r = matcher.match(img, anchor, expected, margin * k)
            r["scale"] = k * s
            if best is None or r["score"] > best["score"]:
                best = r
        return best


# ============================================================
# CALIBRATION ON THE REFERENCE IMAGE
# ============================================================

def eye_centroid(gray, near, radius=10):
    """Centroid of the bright eye spot close to `near` (used on the reference image only)."""
    b = cv2.GaussianBlur(gray, (0, 0), 2.5)
    x, y = int(round(near[0])), int(round(near[1]))
    r = int(radius * 2)
    x0, y0 = max(0, x - r), max(0, y - r)
    win = b[y0:y + r + 1, x0:x + r + 1]
    _, _, _, p = cv2.minMaxLoc(win)
    px, py = p[0] + x0, p[1] + y0
    xa, ya = max(0, px - radius), max(0, py - radius)
    w = b[ya:py + radius + 1, xa:px + radius + 1]
    w = np.clip(w - np.percentile(w, 85), 0, None)
    yy, xx = np.mgrid[0:w.shape[0], 0:w.shape[1]]
    s = w.sum()
    if s <= 0:
        return float(px), float(py)
    return float((w * xx).sum() / s + xa), float((w * yy).sum() / s + ya)


def calibrate_one(tpl, matcher, roi_center, corner, margin=60.0):
    """Find the scale and anchor of a raw template on the reference image."""
    scales = np.geomspace(0.25, 2.0, 60)
    best = None
    for s in scales:
        img = resize(tpl.raw, s)
        if min(img.shape) < 12:
            continue
        q = corner_index(corner) - corner_index(tpl.at)
        img = rotate_img(img, q)
        centre = ((img.shape[1] - 1) / 2.0, (img.shape[0] - 1) / 2.0)
        r = matcher.match(img, centre, roi_center, margin)
        if best is None or r["score"] > best[0]:
            best = (r["score"], s)
    s0 = best[1]
    best = None
    for s in s0 * np.linspace(0.95, 1.05, 21):
        img = resize(tpl.raw, s)
        q = corner_index(corner) - corner_index(tpl.at)
        img = rotate_img(img, q)
        centre = ((img.shape[1] - 1) / 2.0, (img.shape[0] - 1) / 2.0)
        r = matcher.match(img, centre, roi_center, margin)
        if best is None or r["score"] > best["score"]:
            best = dict(r, s=s, q=q, shape=img.shape, centre=centre)
    # matched template-centre position -> template top-left; anchor = ROI centre - top-left
    tlx = best["pos"][0] - best["centre"][0]
    tly = best["pos"][1] - best["centre"][1]
    anchor_rot = (roi_center[0] - tlx, roi_center[1] - tly)
    anchor = rotate_point(anchor_rot, -best["q"], best["shape"])   # back to template orientation
    return best["s"], anchor, best["score"]


def calibrate(templates, ref_path):
    ref = load_gray(ref_path)
    die = detect_die(ref)
    if die is None:
        raise RuntimeError("Calibration: could not find the die in the reference image.")
    matcher = Matcher(ref, pad=1200)

    # Lens: locate roughly, then measure the eye on the image itself (crop-independent)
    lens = templates["lens"]
    s_l, _, sc_l = calibrate_one(lens, matcher, die["center"], "TL", margin=LENS_SEARCH_FRAC * die["side"])
    img = resize(lens.raw, s_l)
    centre = ((img.shape[1] - 1) / 2.0, (img.shape[0] - 1) / 2.0)
    r = matcher.match(img, centre, die["center"], LENS_SEARCH_FRAC * die["side"])
    eye = eye_centroid(ref, r["pos"])
    s_l, a_l, sc_l = calibrate_one(lens, matcher, eye, "TL", margin=20)

    roi_centres = {
        "inner": [("TL", (eye[0] + REF_INNER_OFFSET[0], eye[1] + REF_INNER_OFFSET[1]))],
        "corner": [(c, (eye[0] + CORNER_SIGN[c][0] * REF_MARK_OFFSET,
                        eye[1] + CORNER_SIGN[c][1] * REF_MARK_OFFSET)) for c in ("TR", "BL")],
        "label": [("TL", (eye[0] + REF_LABEL_OFFSET[0], eye[1] + REF_LABEL_OFFSET[1]))],
    }
    results = {"lens": (s_l, a_l, sc_l)}
    for name, targets in roi_centres.items():
        fits = [calibrate_one(templates[name], matcher, c, corner) for corner, c in targets]
        s = float(np.mean([f[0] for f in fits]))
        a = (float(np.mean([f[1][0] for f in fits])), float(np.mean([f[1][1] for f in fits])))
        results[name] = (s, a, float(np.mean([f[2] for f in fits])))

    print("Calibration on reference image:")
    for name, (s, a, sc) in results.items():
        t = templates[name]
        t.scale = s
        t.norm = resize(t.raw, s)          # anchors were measured on exactly this image
        t.anchor = (a[0], a[1])
        t.calib_score = sc
        flag = "" if sc >= 0.6 else "   <-- low, check this template"
        print(f"  {name:6s} template scale x{s:.3f}  ({t.raw.shape[1]}x{t.raw.shape[0]} -> "
              f"{t.norm.shape[1]}x{t.norm.shape[0]})  score {sc:.3f}{flag}")
    return die["side"]


# ============================================================
# DETECTION
# ============================================================

def label_texture(gray, center, size):
    """Texture inside the expected label box (high for a label, low for blank die)."""
    w, h = size
    x0, y0 = int(round(center[0] - w / 2)), int(round(center[1] - h / 2))
    x1, y1 = int(round(center[0] + w / 2)), int(round(center[1] + h / 2))
    H, W = gray.shape
    x0, y0, x1, y1 = max(0, x0), max(0, y0), min(W, x1), min(H, y1)
    if x1 - x0 < 5 or y1 - y0 < 5:
        return 0.0
    patch = cv2.GaussianBlur(gray[y0:y1, x0:x1], (0, 0), 1.5)
    lo, hi = np.percentile(patch, (10, 90))
    return float(hi - lo)


def detect(gray, templates, ref_die_side):
    H, W = gray.shape
    warnings = []
    out = {"warnings": warnings}

    # ---- 0. die square -> coarse centre and scale
    die = detect_die(gray)
    out["die"] = die
    if die is None:
        warnings.append("die not found: using image centre")
        c0, k = (W / 2.0, H / 2.0), 1.0
        die_side = ref_die_side
    else:
        c0, die_side = die["center"], die["side"]
        k = die_side / ref_die_side
        if abs(die["angle"]) > 1.0:
            warnings.append(f"die tilted {die['angle']:.1f} deg")
    k = float(np.clip(k, 0.8, 1.25))
    out["scale_die"] = k

    pad = 1.3 * max(max(templates[n].norm.shape) for n in ("lens", "corner", "label")) + 0.2 * die_side
    m = Matcher(gray, pad)
    searches = []

    # ---- 1. lens eye
    lens = templates["lens"].best_over_scales(m, c0, LENS_SEARCH_FRAC * ref_die_side, k, SCALES_COARSE)
    searches.append(lens["window"])
    lens_ok = lens["score"] >= LENS_MIN_SCORE
    eye = lens["pos"] if lens_ok else c0
    if not lens_ok:
        warnings.append(f"lens weak ({lens['score']:.2f}): centre from die")
    out["lens"] = lens

    # ---- 2. corner marks: test both diagonals
    corner_margin = CORNER_SEARCH_FRAC * ref_die_side * (1.0 if lens_ok else 2.0)
    marks = {}
    for c in CORNERS:
        sx, sy = CORNER_SIGN[c]
        exp = (eye[0] + sx * REF_MARK_OFFSET * k, eye[1] + sy * REF_MARK_OFFSET * k)
        marks[c] = templates["corner"].best_over_scales(m, exp, corner_margin, k, SCALES_COARSE, corner=c)
        marks[c]["expected"] = exp
        searches.append(marks[c]["window"])

    diag_scores = {}
    for dname, (c1, c2) in DIAGONALS.items():
        p1, p2 = marks[c1]["pos"], marks[c2]["pos"]
        mid = ((p1[0] + p2[0]) / 2, (p1[1] + p2[1]) / 2)
        dist = math.hypot(p1[0] - p2[0], p1[1] - p2[1])
        expected = REF_MARK_DIAGONAL * k
        geo = (math.hypot(mid[0] - eye[0], mid[1] - eye[1]) + abs(dist - expected)) / expected
        if not lens_ok:
            geo = abs(dist - expected) / expected          # eye unknown: only check spacing
        mean = 0.5 * (marks[c1]["score"] + marks[c2]["score"])
        diag_scores[dname] = {"score": mean - GEOMETRY_WEIGHT * geo, "mean": mean, "geo": geo,
                              "dist": dist, "mid": mid}
    ranked = sorted(diag_scores, key=lambda d: diag_scores[d]["score"], reverse=True)
    diag = ranked[0]
    diag_margin = diag_scores[ranked[0]]["score"] - diag_scores[ranked[1]]["score"]
    if diag_margin < DIAGONAL_MIN_MARGIN:
        warnings.append(f"diagonal margin low ({diag_margin:.2f})")
    out["diagonal"], out["diagonal_scores"], out["diagonal_margin"] = diag, diag_scores, diag_margin

    # refine scale and (if needed) centre from the two marks
    c1, c2 = DIAGONALS[diag]
    both_marks = all(marks[c]["score"] >= CORNER_MIN_SCORE for c in (c1, c2))
    geo_ok = diag_scores[diag]["geo"] < 0.02
    scale_trusted = both_marks and geo_ok
    if scale_trusted:
        k = diag_scores[diag]["dist"] / REF_MARK_DIAGONAL
        if not lens_ok:
            eye = diag_scores[diag]["mid"]
            warnings.append("centre from corner marks")
    elif lens_ok:
        # one usable mark: its distance to the eye still gives the scale
        good = [c for c in (c1, c2) if marks[c]["score"] >= CORNER_MIN_SCORE]
        if good:
            p = marks[good[0]]["pos"]
            k1 = math.hypot(p[0] - eye[0], p[1] - eye[1]) / (REF_MARK_DIAGONAL / 2.0)
            if abs(k1 / k - 1.0) < 0.05:
                k, scale_trusted = k1, True
    out["scale"] = k

    # ---- 3. label: two candidate corners for this diagonal
    labels = {}
    for c in LABEL_CORNERS_FOR[diag]:
        q = corner_index(c)                      # label sits at TL when q = 0
        off = rotate_vec(REF_LABEL_OFFSET, q)
        exp = (eye[0] + off[0] * k, eye[1] + off[1] * k)
        size = REF_LABEL_SIZE if q % 2 == 0 else REF_LABEL_SIZE[::-1]
        r = templates["label"].best_over_scales(m, exp, LABEL_SEARCH_FRAC * ref_die_side, k, SCALES_FINE, corner=c)
        r["expected"] = exp
        r["texture"] = label_texture(gray, exp, (size[0] * k, size[1] * k))
        labels[c] = r
        searches.append(r["window"])
    # Decision: a strong template match wins; otherwise the label-vs-blank texture
    # test decides; if both are weak the template's choice is kept but flagged.
    la, lb = LABEL_CORNERS_FOR[diag]
    if labels[lb]["score"] > labels[la]["score"]:
        la, lb = lb, la
    label_margin = labels[la]["score"] - labels[lb]["score"]
    by_tex = max(labels, key=lambda c: labels[c]["texture"])
    other = la if by_tex == lb else lb
    tex_ratio = (labels[by_tex]["texture"] + 1e-6) / (labels[other]["texture"] + 1e-6)
    if labels[la]["score"] >= LABEL_STRONG_SCORE and label_margin >= LABEL_MIN_MARGIN:
        label_corner, label_method = la, "template"
    elif tex_ratio >= BLANK_MIN_RATIO:
        label_corner, label_method = by_tex, "blank-test"
    elif labels[la]["score"] >= LABEL_MIN_SCORE and label_margin >= LABEL_MIN_MARGIN:
        label_corner, label_method = la, "template"
    else:
        label_corner, label_method = la, "uncertain"
        warnings.append("label corner uncertain: rotation may be 180 deg off")
    out["labels"], out["label_corner"], out["label_method"] = labels, label_corner, label_method
    out["label_margin"], out["label_texture_ratio"] = label_margin, tex_ratio
    out["label_texture_corner"] = by_tex

    q = corner_index(label_corner)               # image = canonical rotated q*90 deg CW
    out["rotation_cw"] = 90 * q

    # ---- 4. inner area (verification + safety net)
    ioff = rotate_vec(REF_INNER_OFFSET, q)
    iexp = (eye[0] + ioff[0] * k, eye[1] + ioff[1] * k)
    inner_scales = SCALES_FINE if scale_trusted else tuple(np.arange(0.97, 1.0301, 0.005))
    inner = templates["inner"].best_over_scales(m, iexp, INNER_SEARCH_FRAC * ref_die_side, k, inner_scales,
                                                corner=CORNERS[q])      # rotate with the image
    searches.append(inner["window"])
    at_edge = inner["scale"] in (k * inner_scales[0], k * inner_scales[-1])
    if not scale_trusted and inner["score"] >= max(INNER_MIN_SCORE, 0.6) and not at_edge:
        k = inner["scale"]                       # scale from the octagon instead
        out["scale"] = k
        ioff = rotate_vec(REF_INNER_OFFSET, q)
        iexp = (eye[0] + ioff[0] * k, eye[1] + ioff[1] * k)
    out["inner"] = inner
    out["searches"] = searches

    # ---- 5. final ROIs (detected if good and consistent, otherwise geometric)
    tol = POSITION_TOL_FRAC * ref_die_side * k

    def settle(det, pred, min_score):
        ok = det is not None and det["score"] >= min_score and \
            math.hypot(det["pos"][0] - pred[0], det["pos"][1] - pred[1]) <= tol
        return (det["pos"], "detected") if ok else (pred, "geometric")

    rois = {}
    ic, ist = settle(inner, iexp, INNER_MIN_SCORE)
    s, ch = REF_INNER_SIZE * k / 2.0, REF_INNER_CHAMFER * k
    poly = [(-s + ch, -s), (s - ch, -s), (s, -s + ch), (s, s - ch),
            (s - ch, s), (-s + ch, s), (-s, s - ch), (-s, -s + ch)]
    rois["inner"] = {"center": ic, "status": ist, "score": inner["score"],
                     "polygon": [(ic[0] + x, ic[1] + y) for x, y in poly]}

    for canon in ("TR", "BL"):                   # canonical identity of each mark
        c = CORNERS[(corner_index(canon) + q) % 4]
        sx, sy = CORNER_SIGN[c]
        pred = (eye[0] + sx * REF_MARK_OFFSET * k, eye[1] + sy * REF_MARK_OFFSET * k)
        center, st = settle(marks[c], pred, CORNER_MIN_SCORE)
        rois[f"corner_{canon}"] = {"center": center, "status": st, "score": marks[c]["score"],
                                   "image_corner": c, "box": box_of(center, REF_MARK_SIZE, k)}

    off = rotate_vec(REF_LABEL_OFFSET, q)
    pred = (eye[0] + off[0] * k, eye[1] + off[1] * k)
    det = labels[label_corner] if label_method == "template" else None
    center, st = settle(det, pred, LABEL_MIN_SCORE)
    size = REF_LABEL_SIZE if q % 2 == 0 else REF_LABEL_SIZE[::-1]
    rois["label"] = {"center": center, "status": st, "score": labels[label_corner]["score"],
                     "image_corner": label_corner, "method": label_method,
                     "box": box_of(center, size, k)}

    for name, r in rois.items():
        if r["status"] == "geometric":
            warnings.append(f"{name} placed geometrically")
    out["eye"] = eye
    out["rois"] = rois
    return out


def box_of(center, size, k):
    w, h = size[0] * k, size[1] * k
    return [center[0] - w / 2, center[1] - h / 2, center[0] + w / 2, center[1] + h / 2]


# ============================================================
# DRAWING
# ============================================================

def dashed_polyline(img, pts, color, thickness=1, dash=10, gap=7, closed=True):
    pts = [np.array(p, dtype=np.float64) for p in pts]
    if closed:
        pts = pts + [pts[0]]
    for a, b in zip(pts[:-1], pts[1:]):
        length = np.linalg.norm(b - a)
        if length < 1:
            continue
        d = (b - a) / length
        t = 0.0
        while t < length:
            e = min(t + dash, length)
            cv2.line(img, tuple(np.round(a + d * t).astype(int)), tuple(np.round(a + d * e).astype(int)),
                     color, thickness, cv2.LINE_AA)
            t = e + gap


def rect_pts(b):
    x0, y0, x1, y1 = b
    return [(x0, y0), (x1, y0), (x1, y1), (x0, y1)]


def draw(gray, res, name):
    base = to_uint8_stretch(gray) if DISPLAY_STRETCH else to_uint8_plain(gray)
    img = cv2.cvtColor(base, cv2.COLOR_GRAY2BGR)
    H, W = gray.shape
    fs = max(0.4, min(H, W) / 1400.0)
    th = max(1, int(round(min(H, W) / 450)))

    if DRAW_SEARCH_REGIONS:
        for wbox in res["searches"]:
            dashed_polyline(img, rect_pts(wbox), COLORS["search"], 1, 6, 6)
    if DRAW_DIE_SQUARE and res["die"] is not None:
        dashed_polyline(img, res["die"]["box"], COLORS["die"], 1, 14, 8)

    def outline(pts, color, status):
        if status == "detected":
            cv2.polylines(img, [np.round(np.array(pts)).astype(np.int32)], True, color, th + 1, cv2.LINE_AA)
        else:
            dashed_polyline(img, pts, color, th + 1)

    def tag(text, pt, color):
        x, y = int(pt[0]), int(pt[1])
        cv2.putText(img, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, fs, (0, 0, 0), th + 2, cv2.LINE_AA)
        cv2.putText(img, text, (x, y), cv2.FONT_HERSHEY_SIMPLEX, fs, color, th, cv2.LINE_AA)

    rois = res["rois"]
    r = rois["inner"]
    outline(r["polygon"], COLORS["inner"], r["status"])
    tag(f"INNER {r['score']:.2f}" + ("" if r["status"] == "detected" else " (geo)"),
        (r["polygon"][0][0] + 6, r["polygon"][0][1] + 26 * fs / 0.6), COLORS["inner"])

    for key, color, label in (("corner_TR", COLORS["corner"], "CORNER TR"),
                              ("corner_BL", COLORS["corner"], "CORNER BL"),
                              ("label", COLORS["label"], "LABEL")):
        r = rois[key]
        outline(rect_pts(r["box"]), color, r["status"])
        x0, y0, x1, y1 = r["box"]
        txt = f"{label} {r['score']:.2f}" + ("" if r["status"] == "detected" else " (geo)")
        ty = y1 + 22 * fs / 0.6 if y0 < H / 2 else y0 - 8
        tag(txt, (x0, ty), color)

    ex, ey = res["eye"]
    rr = max(6, int(10 * res["scale"]))
    cv2.drawMarker(img, (int(round(ex)), int(round(ey))), COLORS["eye"], cv2.MARKER_CROSS, 3 * rr, th)
    cv2.circle(img, (int(round(ex)), int(round(ey))), rr, COLORS["eye"], th, cv2.LINE_AA)

    lines = [name,
             f"rotation {res['rotation_cw']} deg CW | diagonal {res['diagonal']} "
             f"(margin {res['diagonal_margin']:.2f}) | label {res['label_corner']} ({res['label_method']})"]
    y = int(22 * fs / 0.6) + 4
    for ln in lines:
        tag(ln, (8, y), COLORS["text"])
        y += int(24 * fs / 0.6)
    for wtxt in res["warnings"]:
        tag("! " + wtxt, (8, y), COLORS["warn"])
        y += int(24 * fs / 0.6)
    return img


# ============================================================
# MAIN
# ============================================================

def to_canonical_text(rot_cw):
    return {0: "none", 90: "rotate 90 CCW", 180: "rotate 180", 270: "rotate 90 CW"}[rot_cw]


def jsonable(o):
    if isinstance(o, dict):
        return {k: jsonable(v) for k, v in o.items()}
    if isinstance(o, (list, tuple)):
        return [jsonable(v) for v in o]
    if isinstance(o, (np.floating, float)):
        return round(float(o), 2)
    if isinstance(o, (np.integer,)):
        return int(o)
    return o


def main():
    in_dir, out_dir, tpl_dir = Path(INPUT_DIR), Path(OUTPUT_DIR), Path(TEMPLATE_DIR)
    out_dir.mkdir(parents=True, exist_ok=True)

    templates = {
        "lens": Template(load_gray(tpl_dir / TEMPLATE_FILES["lens"]), "TL"),
        "inner": Template(load_gray(tpl_dir / TEMPLATE_FILES["inner"]), "TL"),
        "corner": Template(load_gray(tpl_dir / TEMPLATE_FILES["corner"]), CORNER_TEMPLATE_AT),
        "label": Template(load_gray(tpl_dir / TEMPLATE_FILES["label"]), LABEL_TEMPLATE_AT),
    }
    ref_die_side = calibrate(templates, REFERENCE_IMAGE)

    files = sorted(p for p in in_dir.iterdir() if p.suffix.lower() in IMAGE_EXTENSIONS)
    print(f"\n{len(files)} images in {in_dir}")
    rows, records = [], []
    for i, path in enumerate(files, 1):
        t0 = time.time()
        try:
            gray = load_gray(path)
            res = detect(gray, templates, ref_die_side)
            cv2.imwrite(str(out_dir / f"{path.stem}_roi.png"), draw(gray, res, path.name))
        except Exception as exc:                         # keep the batch going
            print(f"[{i}/{len(files)}] {path.name}: ERROR {exc}")
            rows.append({"file": path.name, "error": str(exc)})
            continue
        R = res["rois"]
        rows.append({
            "file": path.name,
            "rotation_cw_deg": res["rotation_cw"],
            "to_canonical": to_canonical_text(res["rotation_cw"]),
            "diagonal": res["diagonal"],
            "diagonal_margin": round(res["diagonal_margin"], 3),
            "label_corner": res["label_corner"],
            "label_method": res["label_method"],
            "scale": round(res["scale"], 4),
            "eye_x": round(res["eye"][0], 1), "eye_y": round(res["eye"][1], 1),
            "lens_score": round(res["lens"]["score"], 3),
            "inner_score": round(R["inner"]["score"], 3), "inner_status": R["inner"]["status"],
            "corner_TR_score": round(R["corner_TR"]["score"], 3), "corner_TR_status": R["corner_TR"]["status"],
            "corner_BL_score": round(R["corner_BL"]["score"], 3), "corner_BL_status": R["corner_BL"]["status"],
            "label_score": round(R["label"]["score"], 3), "label_status": R["label"]["status"],
            "label_texture_ratio": round(res["label_texture_ratio"], 2),
            "label_texture_corner": res["label_texture_corner"],
            "die_side": round(res["die"]["side"], 1) if res["die"] else "",
            "die_angle": round(res["die"]["angle"], 2) if res["die"] else "",
            "warnings": "; ".join(res["warnings"]),
            "error": "",
        })
        records.append(jsonable({
            "file": path.name, "rotation_cw_deg": res["rotation_cw"],
            "to_canonical": to_canonical_text(res["rotation_cw"]), "scale": res["scale"],
            "eye": res["eye"], "die": res["die"], "rois": R, "warnings": res["warnings"],
        }))
        flag = "  ! " + "; ".join(res["warnings"]) if res["warnings"] else ""
        print(f"[{i}/{len(files)}] {path.name}: rot {res['rotation_cw']:3d}  "
              f"label {res['label_corner']} ({res['label_method']})  {time.time() - t0:.2f}s{flag}")

    if SAVE_CSV and rows:
        keys = list(dict.fromkeys(k for r in rows for k in r))
        with open(out_dir / "roi_results.csv", "w", newline="") as f:
            w = csv.DictWriter(f, fieldnames=keys)
            w.writeheader()
            w.writerows(rows)
    if SAVE_JSON:
        with open(out_dir / "roi_results.json", "w") as f:
            json.dump(records, f, indent=1)
    print(f"\nDone. Results in {out_dir}")


if __name__ == "__main__":
    main()
