# Inspection dataset tool

Sorts one tray's labelled images into good/bad folders and cuts out the ROIs.
Everything it needs is in this folder. Keep the folder structure as it is.

```
inspection_dataset_tool/
  prepare_dataset_rois.py      the tool (settings at the top)
  top_detection/               TOP detector + its templates
  bottom_detection/            BOTTOM detector + its templates
  1_install.bat  2_check.bat  3_run.bat  3_run_with_debug.bat
```

## Use

1. Double-click `1_install.bat` (first time only).
2. Open `prepare_dataset_rois.py` and edit the CONFIGURATION block at the top:
   - `CSV_FILES`: the two `evaluation_results.csv` files of the tray
     (the `top_bot_...` and `vig_...` folders the annotation tool wrote).
   - `OUTPUT_ROOT`: a NEW, empty folder for the results (one per tray).
3. Double-click `2_check.bat`. It only checks paths and labels and prints the
   counts. Fix any MISSING / ERROR lines first.
4. Double-click `3_run_with_debug.bat` the first time (adds overlay pictures in
   `_debug` so you can see where the ROIs were found), later `3_run.bat`.

From a terminal instead:
`py -3.12 prepare_dataset_rois.py --csv <top_bot csv> <vig csv> --output <new folder>`

## Output

```
vig/good   vig/bad/1f   vig/bad/4f   (vig/bad/2f_3f only if PnP/Wave was f)
top/good   top/bad      bottom/good  bottom/bad        die crops
top_rois/label|corners|inner/good|bad
bottom_rois/pins|triangle|white_boxes|gray_box/good|bad
manifest.csv     one row per image (unit, tags, folder, warnings)
rois_index.csv   one row per ROI crop (detected/weak, score, rotation)
```

Units tagged x (missing data) are skipped. Original images are never changed.
