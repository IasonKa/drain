@echo off
rem Checks the CSVs, image paths and detector files. Writes nothing.
cd /d "%~dp0"
py -3.12 prepare_dataset_rois.py --dry-run
pause
