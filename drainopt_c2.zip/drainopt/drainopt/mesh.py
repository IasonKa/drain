"""
gmsh meshing of the simulation domains.

mesh_fluid  : CFD domain  -> physical groups  fluid | cavity | outlet | drain_wall
mesh_tissue : tissue block -> physical groups tissue | far | interface
              + JSON list of interface facets lying over perforations (suction patches)

Output: Gmsh MSH 2.2 ASCII (read by OpenFOAM `gmshToFoam`, FEBio Studio, meshio).
"""
from __future__ import annotations
import json, math
import numpy as np
import gmsh


ALGO3D = {"hxt": 10, "delaunay": 1}
HEAL_TOL = 0.02          # mm: features below 20 um (hole/rib/spoke near-coincidences) are healed away
_ALGO = ["hxt"]          # set by the CLI; a crash in one algorithm is retried by pipeline.py


def _init(threads, verbose):
    if gmsh.isInitialized():
        gmsh.finalize()
    gmsh.initialize()
    # OpenCascade healing on import: removes sliver edges/faces left where holes
    # graze ribs or the ends of the oval (cause of "point not inserted" crashes)
    for opt in ("OCCFixDegenerated", "OCCFixSmallEdges", "OCCFixSmallFaces", "OCCSewFaces"):
        gmsh.option.setNumber("Geometry." + opt, 1)
    gmsh.option.setNumber("Geometry.Tolerance", 1e-5)
    gmsh.option.setNumber("General.Terminal", 1 if verbose else 0)
    gmsh.option.setNumber("General.NumThreads", threads)
    gmsh.option.setNumber("Mesh.MaxNumThreads3D", threads)


def _classify(info, extra_planes=()):
    """Split boundary surfaces into box faces (by plane), extra planes, and the rest."""
    tol = 1e-4
    planes = [("x", info["x"][0]), ("x", info["x"][1]), ("y", info["y"][0]),
              ("y", info["y"][1]), ("z", info["z"][0]), ("z", info["z"][1])]
    idx = {"x": 0, "y": 1, "z": 2}
    box, extra, rest = [], {k: [] for k, _ in extra_planes}, []
    for _, t in gmsh.model.getEntities(2):
        com = gmsh.model.occ.getCenterOfMass(2, t)
        bb = gmsh.model.getBoundingBox(2, t)
        planar = gmsh.model.getType(2, t) == "Plane"
        hit = None
        if planar:
            for name, z in extra_planes:
                if abs(com[2] - z) < tol and abs(bb[5] - bb[2]) < 1e-3:
                    hit = name
            if hit:
                extra[hit].append(t); continue
            for ax, v in planes:
                i = idx[ax]
                if abs(com[i] - v) < tol and abs(bb[i + 3] - bb[i]) < 1e-3:
                    hit = "box"
            if hit:
                box.append(t); continue
        rest.append(t)
    return box, extra, rest


def _size_field(surfaces, h_min, h_max, dist_max):
    f = gmsh.model.mesh.field
    d = f.add("Distance")
    f.setNumbers(d, "SurfacesList", surfaces)
    f.setNumber(d, "Sampling", 60)
    th = f.add("Threshold")
    f.setNumber(th, "InField", d)
    f.setNumber(th, "SizeMin", h_min); f.setNumber(th, "SizeMax", h_max)
    f.setNumber(th, "DistMin", 0.5 * h_min); f.setNumber(th, "DistMax", dist_max)
    f.setAsBackgroundMesh(th)
    gmsh.option.setNumber("Mesh.MeshSizeExtendFromBoundary", 0)
    gmsh.option.setNumber("Mesh.MeshSizeFromPoints", 0)
    gmsh.option.setNumber("Mesh.MeshSizeFromCurvature", 0)
    gmsh.option.setNumber("Mesh.MeshSizeMin", 0.5 * h_min)
    gmsh.option.setNumber("Mesh.MeshSizeMax", h_max)


def _mesh_and_stats(out_msh):
    gmsh.option.setNumber("Mesh.Algorithm", 6)       # Frontal-Delaunay 2D
    gmsh.option.setNumber("Mesh.Algorithm3D", ALGO3D[_ALGO[0]])
    gmsh.option.setNumber("Mesh.Optimize", 1)
    gmsh.model.mesh.generate(3)
    algo = _ALGO[0]
    gmsh.option.setNumber("Mesh.MshFileVersion", 2.2)
    gmsh.option.setNumber("Mesh.Binary", 0)
    gmsh.option.setNumber("Mesh.SaveAll", 0)
    gmsh.write(out_msh)
    types, tags, _ = gmsh.model.mesh.getElements(3)
    tets = np.concatenate([t for ty, t in zip(types, tags) if ty == 4]) if len(types) else np.array([])
    q = gmsh.model.mesh.getElementQualities(tets.tolist(), "minSICN") if len(tets) else np.array([0])
    nodes = gmsh.model.mesh.getNodes()[0]
    return dict(algorithm=algo, n_nodes=int(len(nodes)), n_tets=int(len(tets)),
                q_min=float(np.min(q)), q_mean=float(np.mean(q)),
                frac_q_below_0p1=float(np.mean(np.asarray(q) < 0.1)))


def mesh_fluid(step_path, info, out_msh, h_min=0.15, h_max=1.0, dist_max=2.5,
               threads=4, verbose=False):
    _init(threads, verbose)
    gmsh.model.add("fluid")
    gmsh.model.occ.importShapes(step_path)
    gmsh.model.occ.healShapes(tolerance=HEAL_TOL)
    gmsh.model.occ.synchronize()
    vols = [t for _, t in gmsh.model.getEntities(3)]
    box, extra, wall = _classify(info, extra_planes=[("outlet", info["z_outlet"])])
    gmsh.model.addPhysicalGroup(3, vols, name="fluid")
    gmsh.model.addPhysicalGroup(2, box, name="cavity")
    gmsh.model.addPhysicalGroup(2, extra["outlet"], name="outlet")
    gmsh.model.addPhysicalGroup(2, wall, name="drain_wall")
    _size_field(wall, h_min, h_max, dist_max)
    st = _mesh_and_stats(out_msh)
    st.update(n_cavity_faces=len(box), n_outlet_faces=len(extra["outlet"]), n_wall_faces=len(wall))
    gmsh.finalize()
    return st


def mesh_tissue(step_path, info, out_msh, hole_d, h_min=0.2, h_max=2.0, dist_max=4.0,
                threads=4, verbose=False):
    _init(threads, verbose)
    gmsh.model.add("tissue")
    gmsh.model.occ.importShapes(step_path)
    gmsh.model.occ.healShapes(tolerance=HEAL_TOL)
    gmsh.model.occ.synchronize()
    vols = [t for _, t in gmsh.model.getEntities(3)]
    box, _, iface = _classify(info)
    gmsh.model.addPhysicalGroup(3, vols, name="tissue")
    gmsh.model.addPhysicalGroup(2, box, name="far")
    gmsh.model.addPhysicalGroup(2, iface, name="interface")
    _size_field(iface, h_min, h_max, dist_max)
    st = _mesh_and_stats(out_msh)
    # ---- interface facets lying over a perforation (holes drilled along y) ----
    holes = np.asarray(info["holes"], float)
    r2 = (hole_d / 2) ** 2
    ntag, xyz, _ = gmsh.model.mesh.getNodes()
    pos = dict(zip(ntag.tolist(), xyz.reshape(-1, 3)))
    facets, hid = [], []
    for s in iface:
        types, _, ncon = gmsh.model.mesh.getElements(2, s)
        for ty, con in zip(types, ncon):
            if ty != 2:
                continue
            tri = con.reshape(-1, 3)
            cen = np.array([np.mean([pos[n] for n in t], axis=0) for t in tri])
            for t, c in zip(tri, cen):
                d2 = (holes[:, 0] - c[0]) ** 2 + (holes[:, 1] - c[2]) ** 2
                k = int(np.argmin(d2))
                if d2[k] < r2:
                    facets.append([int(n) for n in t]); hid.append(k)
    json.dump({"facets_node_tags": facets, "hole_index": hid, "hole_d": hole_d},
              open(out_msh.replace(".msh", "_hole_facets.json"), "w"))
    st.update(n_hole_facets=len(facets), n_holes_hit=len(set(hid)))
    gmsh.finalize()
    return st


# ---------------------------------------------------------------------------
# CLI: meshing must run in its own process. gmsh bundles its own OpenCascade,
# which crashes (segfault) if loaded next to CadQuery's OCP in one interpreter.
#   python -m drainopt.mesh fluid  <step> <info.json> <out.msh> --hmin .15 --hmax 1
#   python -m drainopt.mesh tissue <step> <info.json> <out.msh> --hole-d 1.0
# ---------------------------------------------------------------------------
if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("kind", choices=["fluid", "tissue"])
    ap.add_argument("step"); ap.add_argument("info"); ap.add_argument("out")
    ap.add_argument("--hmin", type=float); ap.add_argument("--hmax", type=float)
    ap.add_argument("--hole-d", type=float, default=1.0)
    ap.add_argument("--threads", type=int, default=4); ap.add_argument("--verbose", action="store_true")
    ap.add_argument("--algo", choices=list(ALGO3D), default="hxt")
    a = ap.parse_args()
    _ALGO[0] = a.algo
    info = json.load(open(a.info))
    kw = dict(threads=a.threads, verbose=a.verbose)
    if a.hmin: kw["h_min"] = a.hmin
    if a.hmax: kw["h_max"] = a.hmax
    if a.kind == "fluid":
        st = mesh_fluid(a.step, info, a.out, **kw)
    else:
        st = mesh_tissue(a.step, info, a.out, a.hole_d, **kw)
    print("MESHSTATS " + json.dumps(st))
