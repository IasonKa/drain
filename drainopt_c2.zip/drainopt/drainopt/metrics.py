"""
Cheap geometric + analytical metrics for a design (no CFD needed).

They are useful for (a) sanity-checking variants, (b) as extra inputs/features for
the surrogate model, and (c) rejecting obviously bad designs before meshing.
"""
from __future__ import annotations
import math
import numpy as np
import cadquery as cq

from .params import DrainParams
from . import cad


def _area(faces):
    return float(sum(f.Area() for f in faces))


def _perimeter(faces):
    return float(sum(w.Length() for f in faces for w in [f.outerWire()] + f.innerWires()))


def section_metrics(p: DrainParams):
    a, b, t = p.sheath_a, p.sheath_b, p.sheath_t
    sheath = cad.build_section(p, "sheath")
    core = cad.build_section(p, "core")
    A_env = math.pi * a * b                                  # envelope (outer oval)
    A_mat = _area(sheath) + _area(core)
    # sheath lumen: inside inner oval, outside the core's outer circle, minus ribs
    A_core_env = math.pi * p.core_ro ** 2
    A_sheath_lumen = A_env - _area(sheath) - A_core_env
    A_core_lumen = A_core_env - _area(core)
    # wetted perimeters (rough: all walls bounding each lumen)
    P_sheath_in = _perimeter(sheath) - 2 * math.pi * math.sqrt((a**2 + b**2) / 2)  # minus outer oval
    P_core = _perimeter(core)
    Dh_sheath = 4 * A_sheath_lumen / (P_sheath_in + 2 * math.pi * p.core_ro)
    Dh_core = 4 * A_core_lumen / P_core
    return dict(A_envelope=A_env, A_material=A_mat,
                A_sheath_lumen=A_sheath_lumen, A_core_lumen=A_core_lumen,
                A_fluid_total=A_env - A_mat,
                Dh_sheath=Dh_sheath, Dh_core=Dh_core)


def perforation_metrics(p: DrainParams):
    holes = cad.hole_centres(p)
    n_through = len(holes)
    # each through-hole opens the sheath twice (top + bottom wall)
    A_open = n_through * 2 * math.pi * p.hole_d ** 2 / 4
    # outer sheath surface over the perforated length (Ramanujan perimeter)
    a, b = p.sheath_a, p.sheath_b
    h = ((a - b) / (a + b)) ** 2
    perim = math.pi * (a + b) * (1 + 3 * h / (10 + math.sqrt(4 - 3 * h)))
    zs = sorted({z for _, z in holes})
    L_perf = (zs[-1] - zs[0] + p.row_pitch) if zs else 0.0
    porosity = A_open / (perim * L_perf) if L_perf else 0.0
    return dict(n_through_holes=n_through, n_openings=2 * n_through,
                A_open=A_open, perforated_length=L_perf,
                open_area_ratio=porosity,
                ligament_axial=p.row_pitch - p.hole_d,
                ligament_lateral=p.hole_pitch_x - p.hole_d)


def tube_metrics(p: DrainParams, mu=3.5e-3):
    """Poiseuille resistance of the extension tube. mu in Pa*s (blood ~3.5e-3)."""
    P = cad.tube_path_points(p)
    L = float(np.linalg.norm(np.diff(P, axis=0), axis=1).sum())        # mm
    r = p.tube_ri * 1e-3
    R_hyd = 8 * mu * (L * 1e-3) / (math.pi * r ** 4)                   # Pa*s/m^3
    # flow at 10 kPa suction (~75 mmHg) if the tube were the only resistance
    Q = 1e4 / R_hyd * 1e6 * 60                                         # mL/min
    return dict(tube_length=L, tube_min_bend_radius=cad.min_bend_radius(P),
                tube_R_hyd=R_hyd, tube_Q_at_10kPa_mL_min=Q)


def solid_metrics(drain_wp: cq.Workplane):
    s = drain_wp.solids().vals()
    return dict(n_solids=len(s), volume=float(sum(x.Volume() for x in s)),
                surface_area=float(sum(x.Area() for x in s)))


def all_metrics(p: DrainParams, drain_wp=None):
    m = {}
    m.update(section_metrics(p)); m.update(perforation_metrics(p)); m.update(tube_metrics(p))
    if drain_wp is not None:
        m.update(solid_metrics(drain_wp))
    m["violations"] = p.check()
    return m
