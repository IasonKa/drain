"""One design -> CAD -> metrics -> simulation domains -> meshes.  Used locally and on HPC."""
from __future__ import annotations
import os, json, time, traceback, subprocess, sys
import cadquery as cq
from .params import DrainParams
from . import cad, metrics


def segment_params(p: DrainParams, n_rows: int) -> DrainParams:
    """Short 'section model': same cross-section, holes, tip and taper, only n_rows rows."""
    margin = 1.0
    body = (n_rows - 1) * p.row_pitch + p.hole_d + 2 * margin
    return p.replace(body_len=body, n_rows=n_rows, first_row_z=margin + p.hole_d / 2)


def _mesh_subprocess(kind, step, info, out, threads, verbose, **kw):
    """Run drainopt.mesh in a separate interpreter (gmsh/OCP conflict, see mesh.py)."""
    pkg_root = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    cmd = [sys.executable, "-m", "drainopt.mesh", kind, step, info, out, "--threads", str(threads)]
    for k, v in kw.items():
        if v is not None:
            cmd += ["--" + k.replace("_", "-"), str(v)]
    if verbose:
        cmd.append("--verbose")
    env = dict(os.environ, PYTHONPATH=pkg_root + os.pathsep + os.environ.get("PYTHONPATH", ""))
    errs = []
    for algo in ("hxt", "delaunay"):      # fresh process per attempt: a segfault can't be caught in-process
        r = subprocess.run(cmd + ["--algo", algo], capture_output=True, text=True, env=env)
        with open(out.replace(".msh", f"_mesh_{algo}.log"), "w") as f:
            f.write(r.stdout + "\n" + r.stderr)
        for line in r.stdout.splitlines():
            if line.startswith("MESHSTATS "):
                return json.loads(line[10:])
        errs.append(f"{algo}: exit {r.returncode} {r.stderr[-300:]}")
    raise RuntimeError(f"{kind} meshing failed: " + " | ".join(errs))


def run_variant(p: DrainParams, outdir, mesh=True, tissue=False, full_tube=False,
                h_min=0.2, h_max=1.2, threads=4, verbose=False):
    os.makedirs(outdir, exist_ok=True)
    T = time.time(); rec = {"outdir": outdir}
    p.save(os.path.join(outdir, "params.json"))
    viol = p.check()
    if viol:
        rec.update(status="infeasible", violations=viol)
    else:
        try:
            drain = cad.build_drain(p, tube="full" if full_tube else "stub")
            cad.export(drain, os.path.join(outdir, "drain"))
            m = metrics.all_metrics(p, drain)
            fluid, info = cad.build_fluid_domain(p)
            cq.exporters.export(fluid, os.path.join(outdir, "fluid.step"))
            json.dump(info, open(os.path.join(outdir, "fluid_info.json"), "w"), indent=1)
            if mesh:
                st = _mesh_subprocess("fluid", os.path.join(outdir, "fluid.step"),
                                      os.path.join(outdir, "fluid_info.json"),
                                      os.path.join(outdir, "fluid.msh"), threads, verbose,
                                      hmin=h_min, hmax=h_max)
                m.update({"fluidmesh_" + k: v for k, v in st.items()})
            if tissue:
                tis, tinfo = cad.build_tissue_domain(p)
                cq.exporters.export(tis, os.path.join(outdir, "tissue.step"))
                json.dump(tinfo, open(os.path.join(outdir, "tissue_info.json"), "w"), indent=1)
                st = _mesh_subprocess("tissue", os.path.join(outdir, "tissue.step"),
                                      os.path.join(outdir, "tissue_info.json"),
                                      os.path.join(outdir, "tissue.msh"), threads, verbose,
                                      hole_d=p.hole_d)
                m.update({"tissuemesh_" + k: v for k, v in st.items()})
            rec.update(status="ok", metrics=m)
        except Exception as e:
            rec.update(status="error", error=repr(e), traceback=traceback.format_exc())
    rec["seconds"] = round(time.time() - T, 1)
    json.dump(rec, open(os.path.join(outdir, "result.json"), "w"), indent=2, default=str)
    return rec
