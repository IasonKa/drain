"""
Design parameters for the perforated drain.

All lengths in mm. CAD frame:
  +z  = drain axis, tip at z = 0, tube exits at the +z end
  x   = major axis of the oval sheath
  y   = minor axis (perforations are drilled along y, through-all)

Baseline values were measured from drainage-3D.stp / .stl (Inventor 2025 export).
"""
from __future__ import annotations
from dataclasses import dataclass, asdict, field, fields
import json, math


@dataclass
class DrainParams:
    # ---- outer sheath (oval) ----
    sheath_a: float = 8.93          # outer semi-axis, major (x)
    sheath_b: float = 4.84          # outer semi-axis, minor (y)
    sheath_t: float = 0.62          # sheath wall thickness
    n_ribs: int = 16                # inward ribs, evenly spaced by arc length
    rib_h: float = 1.20             # rib height measured from the inner wall
    rib_w: float = 0.45             # rib width
    rib_phase: float = 0.5          # rib position offset, fraction of rib spacing
    rib_angles: tuple = (14.4, 31.8, 63.5, 77.1)
    # ^ explicit rib positions (ellipse parameter angle, deg, first quadrant,
    #   mirrored 4-fold) measured from the reference. Empty tuple -> use
    #   n_ribs evenly spaced by arc length (what the optimiser varies).
    gusset_x: float = 4.20          # x of the vertical edge of the 4 triangular gussets
    gusset_leg: float = 1.40        # gusset extent along the wall (0 = no gussets)
    gusset_depth: float = 1.90      # gusset depth measured from the inner wall
    wedge_h: float = 1.15           # trapezoid ribs at top/bottom centre (0 = none)

    # ---- inner slotted core tube (same OD/ID as the extension tube) ----
    core_ro: float = 2.80
    core_ri: float = 2.11
    n_slots: int = 6                # longitudinal slots through the core wall
    slot_w: float = 0.60
    n_spokes: int = 6               # internal star divider (0 = open core)
    spoke_w_root: float = 0.45     # width at the centre
    spoke_w_tip: float = 1.00      # width where it meets the core wall

    # ---- body / ends ----
    body_len: float = 119.8         # perforated body length (tip -> start of taper)
    tip_closed: bool = False        # baseline tip is an open cut end
    tip_cap_t: float = 1.0          # cap thickness if tip_closed
    taper_len: float = 11.5         # oval -> tube transition
    taper_end_r: float = 3.30       # outer radius where the sheath meets the tube

    # ---- perforations (through-all along y) ----
    hole_d: float = 1.00
    holes_per_row: int = 6
    hole_pitch_x: float = 3.30      # spacing of holes within a row
    row_pitch: float = 2.249        # axial spacing between rows
    n_rows: int = 54
    row_stagger: float = 0.76       # every second row is shifted by -row_stagger in x
    row_x_offset: float = -0.105    # x of the first row's pattern centre
    first_row_z: float = -0.27      # baseline first row sits on the tip edge
    hole_depth: str = "through"     # 'through' = straight through everything (original)
                                    # 'outer'   = only through the outer oval wall
    hole_clearance: float = 0.05    # min. distance between a hole's edge/centre line and any
                                    # rib/spoke/wall corner; holes are nudged to respect it.
                                    # 0 = no nudging (exact replica of the original)
    hole_max_nudge: float = 0.50    # largest allowed sideways shift of a hole

    # ---- extension tube ----
    tube_ro: float = 2.80
    tube_ri: float = 2.11
    tube_path: str = "baseline"     # 'baseline' (measured), 'straight', or a CSV path
    tube_len_straight: float = 60.0 # used when tube_path == 'straight'

    # ------------------------------------------------------------------
    def to_dict(self):
        return asdict(self)

    def save(self, path):
        with open(path, "w") as f:
            json.dump(self.to_dict(), f, indent=2)

    @classmethod
    def load(cls, path):
        with open(path) as f:
            d = json.load(f)
        if "rib_angles" in d:
            d["rib_angles"] = tuple(d["rib_angles"])
        names = {f.name for f in fields(cls)}
        return cls(**{k: v for k, v in d.items() if k in names})

    def replace(self, **kw):
        d = self.to_dict(); d.update(kw)
        return DrainParams(**d)

    # ------------------------------------------------------------------
    def check(self):
        """Return a list of manufacturability / geometry violations (empty = OK)."""
        p, err = self, []
        ai, bi = p.sheath_a - p.sheath_t, p.sheath_b - p.sheath_t
        if p.sheath_a <= p.sheath_b:
            err.append("sheath_a must exceed sheath_b")
        if p.sheath_t < 0.3:
            err.append("sheath wall < 0.3 mm")
        # rib / wedge tips must not touch the core (reference wedge gap = 0.27 mm)
        if bi - p.rib_h - p.core_ro < 0.2:
            err.append("ribs too tall: < 0.2 mm gap to core")
        if p.wedge_h > 0 and bi - p.wedge_h - p.core_ro < 0.2:
            err.append("wedge too tall: < 0.2 mm gap to core")
        if p.core_ri >= p.core_ro - 0.3:
            err.append("core wall < 0.3 mm")
        # slots must leave material between them
        circ = 2 * math.pi * p.core_ri
        if p.n_slots * p.slot_w > 0.6 * circ:
            err.append("core slots remove > 60% of circumference")
        # hole ligaments
        if p.row_pitch - p.hole_d < 0.4:
            err.append("axial ligament between holes < 0.4 mm")
        if p.hole_pitch_x - p.hole_d < 0.4:
            err.append("lateral ligament between holes < 0.4 mm")
        xs = [p.row_x_offset - k * p.row_stagger + (j - (p.holes_per_row - 1) / 2) * p.hole_pitch_x
              for k in (0, 1) for j in range(p.holes_per_row)]
        if max(abs(x) for x in xs) > p.sheath_a + p.hole_d / 2:
            err.append("hole pattern wider than sheath (holes would miss the drain)")
        perf_len = p.first_row_z + (p.n_rows - 1) * p.row_pitch
        if perf_len > p.body_len + 0.01:
            err.append("perforated length exceeds body length")
        if p.hole_depth not in ("through", "outer"):
            err.append("hole_depth must be 'through' or 'outer'")
        if p.hole_clearance > 0:
            from .cad import hole_layout          # local import (cad imports params)
            info = hole_layout(p)[1]
            if info["unresolved"]:
                err.append(f"{info['unresolved']} hole(s) cannot meet the clearance rule")
            if info["min_ligament"] < 0.3:
                err.append("nudged holes leave < 0.3 mm between neighbours")
        if p.taper_end_r <= p.tube_ro:
            err.append("taper_end_r must exceed tube_ro")
        return err

    # derived quantities -------------------------------------------------
    @property
    def total_holes(self):
        return self.holes_per_row * self.n_rows


BASELINE = DrainParams()                        # original layout + clearance rule (meshable)
REFERENCE = DrainParams(hole_clearance=0.0)     # exact replica of the Inventor file


# Design space for DOE / optimisation: name -> (low, high, kind)
DESIGN_SPACE = {
    "hole_d":        (0.6, 2.0, "float"),
    "holes_per_row": (3,   7,   "int"),
    "hole_pitch_x":  (2.2, 4.5, "float"),
    "row_pitch":     (1.6, 5.0, "float"),
    "row_stagger":   (0.0, 1.6, "float"),
    "sheath_t":      (0.45, 1.0, "float"),
    "sheath_b":      (4.0, 5.5, "float"),
    "n_ribs":        (8,   24,  "int"),
    "rib_h":         (0.5, 1.5, "float"),
    "n_slots":       (3,   8,   "int"),
    "slot_w":        (0.3, 1.2, "float"),
    "tip_closed":    (0,   1,   "bool"),
    "hole_depth":    (0,   1,   ("through", "outer")),
}


def from_unit(u, base: DrainParams = BASELINE, space=DESIGN_SPACE):
    """Map a point u in [0,1]^d to DrainParams. Keeps perforated length ~ baseline."""
    kw = {}
    for ui, (name, (lo, hi, kind)) in zip(u, space.items()):
        v = lo + ui * (hi - lo)
        if isinstance(kind, tuple):                       # categorical choice
            v = kind[min(int(ui * len(kind)), len(kind) - 1)]
        elif kind == "int":
            v = int(round(v))
        elif kind == "bool":
            v = bool(ui >= 0.5)
        kw[name] = v
    kw.setdefault("rib_angles", ())          # optimiser uses uniform rib spacing
    p = base.replace(**kw)
    # --- repair: scale dependent features so most samples are buildable ---
    gap = p.sheath_b - p.sheath_t - p.core_ro            # room between inner wall and core
    p = p.replace(rib_h=min(p.rib_h, gap - 0.3),
                  wedge_h=max(0.0, min(base.wedge_h, gap - 0.3)),
                  gusset_depth=max(0.3, min(base.gusset_depth, gap + 0.5)))
    # shrink lateral pitch if the hole pattern would overhang the sheath
    half = p.sheath_a - 0.6 - p.row_stagger / 2
    if p.holes_per_row > 1 and (p.holes_per_row - 1) * p.hole_pitch_x / 2 > half:
        p = p.replace(hole_pitch_x=max(p.hole_d + 0.4, 2 * half / (p.holes_per_row - 1)))
    # keep the perforated zone centred and inside the body, ~same length as baseline
    margin = 1.5
    n_rows = max(2, int((p.body_len - 2 * margin) // p.row_pitch) + 1)
    first = (p.body_len - (n_rows - 1) * p.row_pitch) / 2
    p = p.replace(n_rows=n_rows, first_row_z=first, row_x_offset=p.row_stagger / 2)
    return p
