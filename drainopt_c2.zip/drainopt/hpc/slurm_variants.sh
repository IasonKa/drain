#!/bin/bash
# Run every design in a manifest as a SLURM job array (one design per task).
#   1) plan:   python3 scripts/generate_variants.py --n 200 --out runs/doe1 --segment-rows 0
#   2) submit: sbatch --array=0-200%40 hpc/slurm_variants.sh runs/doe1/manifest.csv
# %40 = at most 40 designs at once; tune to your allocation.
#SBATCH --job-name=drainopt
#SBATCH --cpus-per-task=8
#SBATCH --mem=24G
#SBATCH --time=04:00:00
#SBATCH --output=logs/%x_%A_%a.out
set -euo pipefail
MANIFEST=${1:?usage: sbatch --array=0-N hpc/slurm_variants.sh manifest.csv}
mkdir -p logs
apptainer exec --bind "$PWD" drainopt.sif python3 scripts/run_variant.py \
    --manifest "$MANIFEST" --index "$SLURM_ARRAY_TASK_ID" \
    --tissue --threads "$SLURM_CPUS_PER_TASK"
# add --mesh once the fluid meshing step is switched to snappyHexMesh (see README)
