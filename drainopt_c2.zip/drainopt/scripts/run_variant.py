"""
Run ONE design (CAD -> metrics -> domains -> meshes). Entry point for SLURM arrays.

  python scripts/run_variant.py --manifest runs/doe1/manifest.csv --index 3 --mesh
  python scripts/run_variant.py --params my.json --out runs/one --mesh --tissue
--index defaults to $SLURM_ARRAY_TASK_ID.
"""
import sys, os, csv, argparse, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from drainopt.params import DrainParams
from drainopt.pipeline import run_variant

ap = argparse.ArgumentParser()
ap.add_argument("--manifest"); ap.add_argument("--index", type=int)
ap.add_argument("--params"); ap.add_argument("--out")
ap.add_argument("--mesh", action="store_true"); ap.add_argument("--tissue", action="store_true")
ap.add_argument("--full-tube", action="store_true")
ap.add_argument("--hmin", type=float, default=0.15); ap.add_argument("--hmax", type=float, default=1.0)
ap.add_argument("--threads", type=int, default=int(os.environ.get("SLURM_CPUS_PER_TASK", 4)))
a = ap.parse_args()

if a.manifest:
    idx = a.index if a.index is not None else int(os.environ["SLURM_ARRAY_TASK_ID"])
    row = list(csv.DictReader(open(a.manifest)))[idx]
    pfile, out = os.path.join(row["dir"], "params.json"), row["dir"]
else:
    pfile, out = a.params, a.out
p = DrainParams.load(pfile)
rec = run_variant(p, out, mesh=a.mesh, tissue=a.tissue, full_tube=a.full_tube,
                  h_min=a.hmin, h_max=a.hmax, threads=a.threads)
print(json.dumps({k: v for k, v in rec.items() if k != "traceback"}, indent=1, default=str)[:3000])
sys.exit(0 if rec["status"] in ("ok", "infeasible") else 1)
