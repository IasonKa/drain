"""
Plan (and optionally run) a Latin-hypercube design of experiments.

  python scripts/generate_variants.py --n 40 --out runs/doe1 --segment-rows 8
  python scripts/generate_variants.py --n 40 --out runs/doe1 --segment-rows 8 --run --mesh

--segment-rows 0  -> full-length drains (cluster), >0 -> short section models (screening)
Writes <out>/vNNNN/params.json and <out>/manifest.csv. On the cluster, run the
manifest with hpc/slurm_variants.sh instead of --run.
"""
import sys, os, csv, argparse, json
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
from scipy.stats import qmc
from drainopt.params import BASELINE, DESIGN_SPACE, from_unit
from drainopt.pipeline import segment_params, run_variant

ap = argparse.ArgumentParser()
ap.add_argument("--n", type=int, default=20)
ap.add_argument("--seed", type=int, default=0)
ap.add_argument("--out", default="runs/doe")
ap.add_argument("--segment-rows", type=int, default=8)
ap.add_argument("--no-baseline", action="store_true")
ap.add_argument("--run", action="store_true")
ap.add_argument("--mesh", action="store_true")
ap.add_argument("--tissue", action="store_true")
ap.add_argument("--hmin", type=float, default=0.2)
ap.add_argument("--hmax", type=float, default=1.2)
ap.add_argument("--threads", type=int, default=4)
a = ap.parse_args()

os.makedirs(a.out, exist_ok=True)
U = qmc.LatinHypercube(d=len(DESIGN_SPACE), seed=a.seed).random(a.n)
designs = [] if a.no_baseline else [("baseline", BASELINE)]
designs += [(f"lhs{i:04d}", from_unit(u)) for i, u in enumerate(U)]
rows = []
for k, (tag, p) in enumerate(designs):
    if a.segment_rows > 0:
        p = segment_params(p, a.segment_rows)
    vid = f"v{k:04d}"; d = os.path.join(a.out, vid); os.makedirs(d, exist_ok=True)
    p.save(os.path.join(d, "params.json"))
    viol = p.check()
    rows.append(dict(index=k, id=vid, tag=tag, dir=d, feasible=not viol, violations="; ".join(viol)))
with open(os.path.join(a.out, "manifest.csv"), "w", newline="") as f:
    w = csv.DictWriter(f, fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
nf = sum(r["feasible"] for r in rows)
print(f"planned {len(rows)} designs ({nf} feasible) -> {a.out}/manifest.csv")

if a.run:
    from drainopt.params import DrainParams
    for r in rows:
        if not r["feasible"]:
            continue
        p = DrainParams.load(os.path.join(r["dir"], "params.json"))
        rec = run_variant(p, r["dir"], mesh=a.mesh, tissue=a.tissue,
                          h_min=a.hmin, h_max=a.hmax, threads=a.threads)
        msg = rec.get("error", "")
        tets = rec.get("metrics", {}).get("fluidmesh_n_tets", "-")
        print(f"{r['id']} {r['tag']:9s} {rec['status']:10s} {rec['seconds']:7.1f}s tets={tets} {msg}")
