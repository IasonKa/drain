"""Build the parametric baseline and export STEP + STL + params + metrics."""
import sys, os, time, json, argparse
sys.path.insert(0, os.path.join(os.path.dirname(__file__), ".."))
import cadquery as cq
from drainopt.params import REFERENCE as BASELINE
from drainopt import cad, metrics

ap = argparse.ArgumentParser()
ap.add_argument("--out", default="out/baseline")
ap.add_argument("--no-tube", action="store_true")
a = ap.parse_args()
os.makedirs(a.out, exist_ok=True)
T = time.time(); log = lambda *m: print(f"[{time.time()-T:6.1f}s]", *m, flush=True)
p = BASELINE
d = cad.build_drain(p, tube="none" if a.no_tube else "full"); log("drain built")
cq.exporters.export(d, os.path.join(a.out, "drain.step")); log("STEP written")
cq.exporters.export(d, os.path.join(a.out, "drain.stl"), tolerance=0.05, angularTolerance=0.3); log("STL written")
p.save(os.path.join(a.out, "params.json"))
m = metrics.all_metrics(p, d)
json.dump(m, open(os.path.join(a.out, "metrics.json"), "w"), indent=2); log("metrics")
for k, v in m.items():
    print(f"  {k:28s} {v:.4g}" if isinstance(v, float) else f"  {k:28s} {v}")
